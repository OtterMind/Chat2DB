import { pgTable, text, integer, timestamp, boolean, serial } from "drizzle-orm/pg-core";

export const channels = pgTable("channels", {
  id: serial("id").primaryKey(),
  channelId: text("channel_id").notNull().unique(),
  channelTitle: text("channel_title").notNull(),
  description: text("description"),
  thumbnail: text("thumbnail"),
  subscriberCount: text("subscriber_count"),
  videoCount: text("video_count"),
  viewCount: text("view_count"),
  addedAt: timestamp("added_at").defaultNow(),
});

export const videos = pgTable("videos", {
  id: serial("id").primaryKey(),
  channelId: text("channel_id").notNull(),
  videoId: text("video_id").notNull().unique(),
  title: text("title").notNull(),
  description: text("description"),
  thumbnail: text("thumbnail"),
  publishedAt: text("published_at"),
  duration: text("duration"),
  viewCount: text("view_count"),
  likeCount: text("like_count"),
  commentCount: text("comment_count"),
  downloaded: boolean("downloaded").default(false),
  savedAt: timestamp("saved_at").defaultNow(),
});
