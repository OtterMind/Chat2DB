"use client";

import { useState, useEffect, useCallback } from "react";

interface Channel {
  id: number;
  channelId: string;
  channelTitle: string;
  description: string | null;
  thumbnail: string | null;
  subscriberCount: string | null;
  videoCount: string | null;
  viewCount: string | null;
  addedAt: string | null;
}

interface Video {
  id: number;
  channelId: string;
  videoId: string;
  title: string;
  description: string | null;
  thumbnail: string | null;
  publishedAt: string | null;
  duration: string | null;
  viewCount: string | null;
  likeCount: string | null;
  commentCount: string | null;
  downloaded: boolean | null;
  savedAt: string | null;
}

function formatCount(val: string | null): string {
  if (!val) return "0";
  const n = parseInt(val);
  if (isNaN(n)) return "0";
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(1)}M`;
  if (n >= 1_000) return `${(n / 1_000).toFixed(1)}K`;
  return n.toString();
}

function formatDuration(iso: string | null): string {
  if (!iso) return "0:00";
  const match = iso.match(/PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?/);
  if (!match) return "0:00";
  const h = parseInt(match[1] || "0");
  const m = parseInt(match[2] || "0");
  const s = parseInt(match[3] || "0");
  if (h > 0) return `${h}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
  return `${m}:${String(s).padStart(2, "0")}`;
}

function formatDate(dateStr: string | null): string {
  if (!dateStr) return "";
  try {
    return new Date(dateStr).toLocaleDateString("fa-IR", {
      year: "numeric",
      month: "short",
      day: "numeric",
    });
  } catch {
    return dateStr;
  }
}

// ── Icons ────────────────────────────────────────────────────────────────────

function IconYouTube() {
  return (
    <svg viewBox="0 0 24 24" fill="currentColor" width="20" height="20">
      <path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z" />
    </svg>
  );
}

function IconLink() {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" width="18" height="18">
      <path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71" />
      <path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71" />
    </svg>
  );
}

function IconTrash() {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" width="14" height="14">
      <polyline points="3 6 5 6 21 6" />
      <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" />
    </svg>
  );
}

function IconEye() {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" width="14" height="14">
      <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" />
      <circle cx="12" cy="12" r="3" />
    </svg>
  );
}

function IconThumbUp() {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" width="14" height="14">
      <path d="M14 9V5a3 3 0 0 0-3-3l-4 9v11h11.28a2 2 0 0 0 2-1.7l1.38-9a2 2 0 0 0-2-2.3zM7 22H4a2 2 0 0 1-2-2v-7a2 2 0 0 1 2-2h3" />
    </svg>
  );
}

function IconCopy() {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" width="14" height="14">
      <rect x="9" y="9" width="13" height="13" rx="2" ry="2" />
      <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1" />
    </svg>
  );
}

function IconRefresh() {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" width="16" height="16">
      <polyline points="23 4 23 10 17 10" />
      <path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10" />
    </svg>
  );
}

function IconPlay() {
  return (
    <svg viewBox="0 0 24 24" fill="currentColor" width="16" height="16">
      <polygon points="5 3 19 12 5 21 5 3" />
    </svg>
  );
}

function IconPlus() {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" width="18" height="18">
      <line x1="12" y1="5" x2="12" y2="19" />
      <line x1="5" y1="12" x2="19" y2="12" />
    </svg>
  );
}

function IconGrid() {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" width="16" height="16">
      <rect x="3" y="3" width="7" height="7" /><rect x="14" y="3" width="7" height="7" />
      <rect x="14" y="14" width="7" height="7" /><rect x="3" y="14" width="7" height="7" />
    </svg>
  );
}

function IconList() {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" width="16" height="16">
      <line x1="8" y1="6" x2="21" y2="6" /><line x1="8" y1="12" x2="21" y2="12" />
      <line x1="8" y1="18" x2="21" y2="18" /><line x1="3" y1="6" x2="3.01" y2="6" />
      <line x1="3" y1="12" x2="3.01" y2="12" /><line x1="3" y1="18" x2="3.01" y2="18" />
    </svg>
  );
}

// ── Toast ────────────────────────────────────────────────────────────────────

interface Toast {
  id: number;
  message: string;
  type: "success" | "error" | "info";
}

function ToastContainer({ toasts, onRemove }: { toasts: Toast[]; onRemove: (id: number) => void }) {
  return (
    <div style={{ position: "fixed", bottom: 24, right: 24, zIndex: 9999, display: "flex", flexDirection: "column", gap: 10 }}>
      {toasts.map((t) => (
        <div
          key={t.id}
          onClick={() => onRemove(t.id)}
          className="animate-fade-in"
          style={{
            padding: "12px 18px",
            borderRadius: 12,
            background: t.type === "success" ? "rgba(34,197,94,0.15)" : t.type === "error" ? "rgba(239,68,68,0.15)" : "rgba(124,58,237,0.15)",
            border: `1px solid ${t.type === "success" ? "rgba(34,197,94,0.4)" : t.type === "error" ? "rgba(239,68,68,0.4)" : "rgba(124,58,237,0.4)"}`,
            color: t.type === "success" ? "#22c55e" : t.type === "error" ? "#ef4444" : "#a855f7",
            fontSize: 14,
            fontWeight: 500,
            cursor: "pointer",
            maxWidth: 340,
            backdropFilter: "blur(12px)",
          }}
        >
          {t.message}
        </div>
      ))}
    </div>
  );
}

// ── Video Modal ──────────────────────────────────────────────────────────────

function VideoModal({ video, onClose }: { video: Video; onClose: () => void }) {
  const youtubeUrl = `https://www.youtube.com/watch?v=${video.videoId}`;

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
  };
  void copyToClipboard;

  return (
    <div
      onClick={onClose}
      style={{
        position: "fixed", inset: 0, zIndex: 1000,
        background: "rgba(0,0,0,0.8)", backdropFilter: "blur(8px)",
        display: "flex", alignItems: "center", justifyContent: "center", padding: 24,
      }}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="glass-card animate-fade-in"
        style={{ width: "100%", maxWidth: 700, maxHeight: "90vh", overflow: "auto" }}
      >
        {/* Thumbnail */}
        <div style={{ position: "relative", paddingTop: "56.25%", borderRadius: "16px 16px 0 0", overflow: "hidden" }}>
          {video.thumbnail && (
            <img src={video.thumbnail} alt={video.title} style={{ position: "absolute", inset: 0, width: "100%", height: "100%", objectFit: "cover" }} />
          )}
          <div style={{ position: "absolute", inset: 0, background: "linear-gradient(to top, rgba(10,10,15,0.8) 0%, transparent 60%)" }} />
          <div style={{ position: "absolute", bottom: 12, right: 12 }}>
            <span className="badge badge-purple">{formatDuration(video.duration)}</span>
          </div>
          <button onClick={onClose} style={{ position: "absolute", top: 12, left: 12, background: "rgba(0,0,0,0.5)", border: "none", color: "white", borderRadius: 8, padding: "6px 12px", cursor: "pointer", fontSize: 18 }}>✕</button>
        </div>

        <div style={{ padding: 24 }}>
          <h2 style={{ fontSize: 18, fontWeight: 700, color: "var(--text-primary)", lineHeight: 1.4, marginBottom: 12 }}>
            {video.title}
          </h2>

          {/* Stats */}
          <div style={{ display: "flex", gap: 16, marginBottom: 20, flexWrap: "wrap" }}>
            <div style={{ display: "flex", alignItems: "center", gap: 6, color: "var(--text-secondary)", fontSize: 13 }}>
              <IconEye /> {formatCount(video.viewCount)} بازدید
            </div>
            <div style={{ display: "flex", alignItems: "center", gap: 6, color: "var(--text-secondary)", fontSize: 13 }}>
              <IconThumbUp /> {formatCount(video.likeCount)} لایک
            </div>
            <div style={{ color: "var(--text-secondary)", fontSize: 13 }}>
              📅 {formatDate(video.publishedAt)}
            </div>
          </div>

          {/* Actions */}
          <div style={{ display: "flex", gap: 10, flexWrap: "wrap", marginBottom: 20 }}>
            <a
              href={youtubeUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="btn-primary"
              style={{ textDecoration: "none", fontSize: 14 }}
            >
              <IconPlay /> مشاهده در یوتیوب
            </a>
            <button
              className="btn-outline"
              onClick={() => {
                navigator.clipboard.writeText(youtubeUrl);
              }}
            >
              <IconCopy /> کپی لینک
            </button>
            <button
              className="btn-outline"
              onClick={() => {
                navigator.clipboard.writeText(video.title);
              }}
            >
              <IconCopy /> کپی عنوان
            </button>
          </div>

          {/* Description */}
          {video.description && (
            <div>
              <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 8 }}>
                <p style={{ fontSize: 13, fontWeight: 600, color: "var(--text-secondary)" }}>توضیحات</p>
                <button
                  className="btn-outline"
                  onClick={() => {
                    navigator.clipboard.writeText(video.description || "");
                  }}
                  style={{ fontSize: 11, padding: "4px 10px" }}
                >
                  <IconCopy /> کپی توضیحات
                </button>
              </div>
              <div style={{
                background: "rgba(0,0,0,0.3)", borderRadius: 10, padding: 14,
                fontSize: 13, color: "var(--text-secondary)", lineHeight: 1.7,
                maxHeight: 200, overflow: "auto", whiteSpace: "pre-wrap", direction: "ltr", textAlign: "left"
              }}>
                {video.description}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// ── Video Card ───────────────────────────────────────────────────────────────

function VideoCard({
  video,
  viewMode,
  onSelect,
}: {
  video: Video;
  viewMode: "grid" | "list";
  onSelect: (v: Video) => void;
}) {
  const youtubeUrl = `https://www.youtube.com/watch?v=${video.videoId}`;

  if (viewMode === "list") {
    return (
      <div
        className="glass-card video-card"
        style={{ display: "flex", gap: 16, padding: 14, cursor: "pointer", alignItems: "flex-start" }}
        onClick={() => onSelect(video)}
      >
        <div style={{ position: "relative", flexShrink: 0, width: 160, height: 90, borderRadius: 10, overflow: "hidden", background: "#1a1a2e" }}>
          {video.thumbnail && (
            <img src={video.thumbnail} alt={video.title} style={{ width: "100%", height: "100%", objectFit: "cover" }} />
          )}
          <div style={{ position: "absolute", bottom: 4, right: 4 }}>
            <span className="badge badge-purple" style={{ fontSize: 10 }}>{formatDuration(video.duration)}</span>
          </div>
        </div>
        <div style={{ flex: 1, minWidth: 0 }}>
          <p style={{ fontWeight: 600, fontSize: 14, color: "var(--text-primary)", marginBottom: 6, lineHeight: 1.4, overflow: "hidden", display: "-webkit-box", WebkitLineClamp: 2, WebkitBoxOrient: "vertical" }}>
            {video.title}
          </p>
          <div style={{ display: "flex", gap: 14, color: "var(--text-secondary)", fontSize: 12, flexWrap: "wrap" }}>
            <span style={{ display: "flex", alignItems: "center", gap: 4 }}><IconEye />{formatCount(video.viewCount)}</span>
            <span style={{ display: "flex", alignItems: "center", gap: 4 }}><IconThumbUp />{formatCount(video.likeCount)}</span>
            <span>{formatDate(video.publishedAt)}</span>
          </div>
        </div>
        <div style={{ display: "flex", gap: 8, flexShrink: 0 }} onClick={(e) => e.stopPropagation()}>
          <a href={youtubeUrl} target="_blank" rel="noopener noreferrer" className="btn-outline" style={{ fontSize: 12, padding: "6px 12px" }}>
            <IconPlay /> باز کن
          </a>
          <button
            className="btn-outline"
            style={{ fontSize: 12, padding: "6px 12px" }}
            onClick={() => navigator.clipboard.writeText(youtubeUrl)}
          >
            <IconCopy />
          </button>
        </div>
      </div>
    );
  }

  return (
    <div
      className="glass-card video-card"
      style={{ overflow: "hidden", cursor: "pointer" }}
      onClick={() => onSelect(video)}
    >
      <div style={{ position: "relative", paddingTop: "56.25%", background: "#1a1a2e" }}>
        {video.thumbnail && (
          <img src={video.thumbnail} alt={video.title} style={{ position: "absolute", inset: 0, width: "100%", height: "100%", objectFit: "cover" }} />
        )}
        <div style={{ position: "absolute", bottom: 8, right: 8 }}>
          <span className="badge badge-purple" style={{ fontSize: 10 }}>{formatDuration(video.duration)}</span>
        </div>
        <div style={{ position: "absolute", inset: 0, background: "rgba(0,0,0,0)", transition: "background 0.2s" }} className="card-overlay" />
      </div>
      <div style={{ padding: "14px 14px 10px" }}>
        <p style={{
          fontWeight: 600, fontSize: 13, color: "var(--text-primary)", marginBottom: 8,
          lineHeight: 1.4, overflow: "hidden", display: "-webkit-box",
          WebkitLineClamp: 2, WebkitBoxOrient: "vertical", minHeight: 36
        }}>
          {video.title}
        </p>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <div style={{ display: "flex", gap: 10, color: "var(--text-secondary)", fontSize: 11 }}>
            <span style={{ display: "flex", alignItems: "center", gap: 3 }}><IconEye />{formatCount(video.viewCount)}</span>
            <span style={{ display: "flex", alignItems: "center", gap: 3 }}><IconThumbUp />{formatCount(video.likeCount)}</span>
          </div>
          <span style={{ color: "var(--text-secondary)", fontSize: 11 }}>{formatDate(video.publishedAt)}</span>
        </div>
        <div style={{ display: "flex", gap: 8, marginTop: 10 }} onClick={(e) => e.stopPropagation()}>
          <a
            href={youtubeUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="btn-outline"
            style={{ fontSize: 11, padding: "5px 10px", flex: 1, justifyContent: "center", textDecoration: "none" }}
          >
            <IconPlay /> یوتیوب
          </a>
          <button
            className="btn-outline"
            style={{ fontSize: 11, padding: "5px 10px" }}
            onClick={() => navigator.clipboard.writeText(youtubeUrl)}
            title="کپی لینک"
          >
            <IconCopy />
          </button>
        </div>
      </div>
    </div>
  );
}

// ── Main App ─────────────────────────────────────────────────────────────────

export default function HomePage() {
  const [youtubeUrl, setYoutubeUrl] = useState("");
  const [connecting, setConnecting] = useState(false);
  const [channels, setChannels] = useState<Channel[]>([]);
  const [selectedChannel, setSelectedChannel] = useState<Channel | null>(null);
  const [videos, setVideos] = useState<Video[]>([]);
  const [loadingVideos, setLoadingVideos] = useState(false);
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid");
  const [selectedVideo, setSelectedVideo] = useState<Video | null>(null);
  const [toasts, setToasts] = useState<Toast[]>([]);
  const [toastId, setToastId] = useState(0);
  const [searchQuery, setSearchQuery] = useState("");
  const [deletingChannel, setDeletingChannel] = useState<string | null>(null);
  const [showConnectModal, setShowConnectModal] = useState(false);

  const addToast = useCallback((message: string, type: Toast["type"] = "info") => {
    const id = toastId + 1;
    setToastId(id);
    setToasts((prev) => [...prev, { id, message, type }]);
    setTimeout(() => setToasts((prev) => prev.filter((t) => t.id !== id)), 4000);
  }, [toastId]);

  const loadChannels = useCallback(async () => {
    try {
      const res = await fetch("/api/youtube/channels");
      const data = await res.json();
      setChannels(data.channels || []);
    } catch {
      addToast("خطا در بارگذاری کانال‌ها", "error");
    }
  }, [addToast]);

  const loadVideos = useCallback(async (channelId: string) => {
    setLoadingVideos(true);
    try {
      const res = await fetch(`/api/youtube/videos?channelId=${channelId}`);
      const data = await res.json();
      setVideos(data.videos || []);
    } catch {
      addToast("خطا در بارگذاری ویدیوها", "error");
    } finally {
      setLoadingVideos(false);
    }
  }, [addToast]);

  useEffect(() => {
    loadChannels();
  }, [loadChannels]);

  useEffect(() => {
    if (selectedChannel) {
      loadVideos(selectedChannel.channelId);
    }
  }, [selectedChannel, loadVideos]);

  const handleConnect = async () => {
    if (!youtubeUrl.trim()) {
      addToast("لطفاً یک لینک یوتیوب وارد کنید", "error");
      return;
    }
    setConnecting(true);
    try {
      const res = await fetch("/api/youtube/connect", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url: youtubeUrl.trim() }),
      });
      const data = await res.json();
      if (!res.ok) {
        addToast(data.error || "خطا در اتصال به کانال", "error");
        return;
      }
      addToast(`✅ کانال "${data.channel.channelTitle}" با ${data.videosCount} ویدیو اضافه شد!`, "success");
      setYoutubeUrl("");
      setShowConnectModal(false);
      await loadChannels();
      // Auto-select newly connected channel
      setSelectedChannel(data.channel as Channel);
    } catch {
      addToast("خطا در اتصال به سرور", "error");
    } finally {
      setConnecting(false);
    }
  };

  const handleDeleteChannel = async (channelId: string, channelTitle: string) => {
    if (!confirm(`آیا مطمئن هستید که می‌خواهید کانال "${channelTitle}" را حذف کنید؟`)) return;
    setDeletingChannel(channelId);
    try {
      const res = await fetch("/api/youtube/delete-channel", {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ channelId }),
      });
      if (res.ok) {
        addToast(`کانال حذف شد`, "success");
        if (selectedChannel?.channelId === channelId) {
          setSelectedChannel(null);
          setVideos([]);
        }
        await loadChannels();
      }
    } catch {
      addToast("خطا در حذف کانال", "error");
    } finally {
      setDeletingChannel(null);
    }
  };

  const filteredVideos = videos.filter((v) =>
    searchQuery ? v.title.toLowerCase().includes(searchQuery.toLowerCase()) : true
  );

  const copyAllLinks = () => {
    const links = filteredVideos.map((v) => `https://www.youtube.com/watch?v=${v.videoId}`).join("\n");
    navigator.clipboard.writeText(links);
    addToast(`${filteredVideos.length} لینک کپی شد!`, "success");
  };

  const copyAllTitles = () => {
    const titles = filteredVideos.map((v) => v.title).join("\n");
    navigator.clipboard.writeText(titles);
    addToast(`${filteredVideos.length} عنوان کپی شد!`, "success");
  };

  return (
    <div style={{ display: "flex", minHeight: "100vh", background: "var(--bg-primary)" }}>
      {/* ── Sidebar ─────────────────────────────────────────────────────── */}
      <aside style={{
        width: 280, flexShrink: 0, borderLeft: "1px solid var(--border)",
        background: "var(--bg-secondary)", display: "flex", flexDirection: "column",
        height: "100vh", position: "sticky", top: 0, overflow: "auto",
      }}>
        {/* Logo */}
        <div style={{ padding: "24px 20px 20px", borderBottom: "1px solid var(--border)" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <div style={{
              width: 40, height: 40, borderRadius: 12,
              background: "linear-gradient(135deg, #7c3aed, #6366f1)",
              display: "flex", alignItems: "center", justifyContent: "center",
            }}>
              <IconYouTube />
            </div>
            <div>
              <p style={{ fontWeight: 800, fontSize: 16, color: "var(--text-primary)" }}>VideoSync</p>
              <p style={{ fontSize: 11, color: "var(--text-secondary)" }}>YouTube Channel Manager</p>
            </div>
          </div>
        </div>

        {/* Add Channel Button */}
        <div style={{ padding: "16px 16px 8px" }}>
          <button
            className="btn-primary"
            style={{ width: "100%", justifyContent: "center", fontSize: 14 }}
            onClick={() => setShowConnectModal(true)}
          >
            <IconPlus /> اتصال کانال جدید
          </button>
        </div>

        {/* Channels list */}
        <div style={{ flex: 1, padding: "8px 12px", overflow: "auto" }}>
          <p style={{ fontSize: 11, fontWeight: 600, color: "var(--text-secondary)", padding: "8px 6px", letterSpacing: "0.08em", textTransform: "uppercase" }}>
            کانال‌های متصل ({channels.length})
          </p>
          {channels.length === 0 ? (
            <div style={{ textAlign: "center", padding: "32px 16px", color: "var(--text-secondary)" }}>
              <div style={{ fontSize: 32, marginBottom: 10 }}>📺</div>
              <p style={{ fontSize: 13 }}>هنوز کانالی اضافه نشده</p>
            </div>
          ) : (
            <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
              {channels.map((ch) => (
                <div
                  key={ch.channelId}
                  className={`sidebar-item ${selectedChannel?.channelId === ch.channelId ? "active" : ""}`}
                  onClick={() => setSelectedChannel(ch)}
                >
                  <div style={{ flexShrink: 0 }}>
                    {ch.thumbnail ? (
                      <img src={ch.thumbnail} alt={ch.channelTitle} style={{ width: 32, height: 32, borderRadius: "50%", objectFit: "cover" }} />
                    ) : (
                      <div style={{ width: 32, height: 32, borderRadius: "50%", background: "linear-gradient(135deg, #7c3aed, #6366f1)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 14 }}>
                        📺
                      </div>
                    )}
                  </div>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <p style={{ fontSize: 13, fontWeight: 600, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                      {ch.channelTitle}
                    </p>
                    <p style={{ fontSize: 11, color: "var(--text-secondary)" }}>
                      {formatCount(ch.subscriberCount)} subscribers
                    </p>
                  </div>
                  <button
                    onClick={(e) => { e.stopPropagation(); handleDeleteChannel(ch.channelId, ch.channelTitle); }}
                    style={{ background: "none", border: "none", cursor: "pointer", color: "var(--text-secondary)", padding: 4, borderRadius: 6, opacity: deletingChannel === ch.channelId ? 0.5 : 1 }}
                    title="حذف کانال"
                  >
                    <IconTrash />
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      </aside>

      {/* ── Main Content ─────────────────────────────────────────────────── */}
      <main style={{ flex: 1, overflow: "auto" }}>
        {!selectedChannel ? (
          /* Welcome Screen */
          <div style={{
            minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center",
            padding: 40, flexDirection: "column", gap: 32, textAlign: "center",
          }}>
            <div style={{ maxWidth: 600 }}>
              <div className="animate-fade-in" style={{ marginBottom: 24 }}>
                <div style={{
                  width: 80, height: 80, borderRadius: 20,
                  background: "linear-gradient(135deg, #7c3aed, #6366f1)",
                  display: "flex", alignItems: "center", justifyContent: "center",
                  margin: "0 auto 20px", fontSize: 36,
                }}>
                  🎬
                </div>
                <h1 style={{ fontSize: 40, fontWeight: 800, lineHeight: 1.2, marginBottom: 16 }}>
                  <span className="gradient-text">VideoSync</span>
                </h1>
                <p style={{ fontSize: 18, color: "var(--text-secondary)", lineHeight: 1.6, marginBottom: 8 }}>
                  لینک شیر یک ویدیوی یوتیوب را وارد کنید تا به کل کانال وصل شوید
                </p>
                <p style={{ fontSize: 14, color: "var(--text-secondary)", lineHeight: 1.6 }}>
                  تمام ویدیوهای کانال را ببینید، عنوان‌ها و لینک‌ها را کپی کنید و محتوا را در کانال خودتان منتشر کنید
                </p>
              </div>

              {/* How it works */}
              <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 16, marginBottom: 40 }}>
                {[
                  { icon: "🔗", title: "لینک ویدیو", desc: "لینک Share هر ویدیوی یوتیوب را وارد کنید" },
                  { icon: "🤖", title: "اتصال خودکار", desc: "ما به کانال متصل می‌شویم و همه ویدیوها را می‌آوریم" },
                  { icon: "📤", title: "محتوا بگذارید", desc: "عنوان، توضیحات و لینک را کپی کنید و در کانال خودتان منتشر کنید" },
                ].map((step, i) => (
                  <div key={i} className="glass-card" style={{ padding: 20, textAlign: "center" }}>
                    <div style={{ fontSize: 32, marginBottom: 10 }}>{step.icon}</div>
                    <p style={{ fontWeight: 700, fontSize: 14, marginBottom: 6, color: "var(--text-primary)" }}>{step.title}</p>
                    <p style={{ fontSize: 12, color: "var(--text-secondary)", lineHeight: 1.5 }}>{step.desc}</p>
                  </div>
                ))}
              </div>

              <button
                className="btn-primary animate-pulse-glow"
                style={{ fontSize: 16, padding: "16px 36px" }}
                onClick={() => setShowConnectModal(true)}
              >
                <IconLink /> شروع کنید – کانال اضافه کنید
              </button>
            </div>
          </div>
        ) : (
          /* Channel View */
          <div style={{ padding: 32 }}>
            {/* Channel Header */}
            <div className="glass-card animate-fade-in" style={{ padding: 24, marginBottom: 28, display: "flex", gap: 20, alignItems: "flex-start", flexWrap: "wrap" }}>
              <div style={{ flexShrink: 0 }}>
                {selectedChannel.thumbnail ? (
                  <img src={selectedChannel.thumbnail} alt={selectedChannel.channelTitle} style={{ width: 80, height: 80, borderRadius: "50%", objectFit: "cover", border: "3px solid rgba(124,58,237,0.4)" }} />
                ) : (
                  <div style={{ width: 80, height: 80, borderRadius: "50%", background: "linear-gradient(135deg, #7c3aed, #6366f1)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 32 }}>
                    📺
                  </div>
                )}
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 6, flexWrap: "wrap" }}>
                  <h2 style={{ fontSize: 22, fontWeight: 800, color: "var(--text-primary)" }}>{selectedChannel.channelTitle}</h2>
                  <span className="badge badge-green">متصل ✓</span>
                </div>
                <div style={{ display: "flex", gap: 20, flexWrap: "wrap", marginBottom: 8 }}>
                  <div style={{ textAlign: "center" }}>
                    <p style={{ fontSize: 18, fontWeight: 700, color: "var(--accent-light)" }}>{formatCount(selectedChannel.subscriberCount)}</p>
                    <p style={{ fontSize: 11, color: "var(--text-secondary)" }}>دنبال‌کننده</p>
                  </div>
                  <div style={{ textAlign: "center" }}>
                    <p style={{ fontSize: 18, fontWeight: 700, color: "var(--accent-light)" }}>{formatCount(selectedChannel.videoCount)}</p>
                    <p style={{ fontSize: 11, color: "var(--text-secondary)" }}>ویدیو</p>
                  </div>
                  <div style={{ textAlign: "center" }}>
                    <p style={{ fontSize: 18, fontWeight: 700, color: "var(--accent-light)" }}>{formatCount(selectedChannel.viewCount)}</p>
                    <p style={{ fontSize: 11, color: "var(--text-secondary)" }}>کل بازدید</p>
                  </div>
                  <div style={{ textAlign: "center" }}>
                    <p style={{ fontSize: 18, fontWeight: 700, color: "var(--accent-light)" }}>{videos.length}</p>
                    <p style={{ fontSize: 11, color: "var(--text-secondary)" }}>ذخیره شده</p>
                  </div>
                </div>
                <a
                  href={`https://www.youtube.com/channel/${selectedChannel.channelId}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  style={{ fontSize: 12, color: "var(--accent-light)", textDecoration: "none" }}
                >
                  🔗 مشاهده کانال در یوتیوب
                </a>
              </div>
              <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
                <button className="btn-outline" onClick={() => loadVideos(selectedChannel.channelId)}>
                  <IconRefresh /> بروزرسانی
                </button>
              </div>
            </div>

            {/* Toolbar */}
            <div style={{ display: "flex", gap: 12, marginBottom: 20, flexWrap: "wrap", alignItems: "center" }}>
              <input
                className="input-field"
                style={{ maxWidth: 300, fontSize: 14, padding: "10px 14px" }}
                placeholder="جستجو در ویدیوها..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
              <div style={{ display: "flex", gap: 8, marginRight: "auto" }}>
                <button className="btn-outline" onClick={copyAllLinks}>
                  <IconCopy /> کپی همه لینک‌ها ({filteredVideos.length})
                </button>
                <button className="btn-outline" onClick={copyAllTitles}>
                  <IconCopy /> کپی همه عنوان‌ها
                </button>
                <button
                  className={`btn-outline ${viewMode === "grid" ? "active" : ""}`}
                  style={viewMode === "grid" ? { borderColor: "var(--accent)", color: "var(--accent-light)" } : {}}
                  onClick={() => setViewMode("grid")}
                >
                  <IconGrid />
                </button>
                <button
                  className={`btn-outline ${viewMode === "list" ? "active" : ""}`}
                  style={viewMode === "list" ? { borderColor: "var(--accent)", color: "var(--accent-light)" } : {}}
                  onClick={() => setViewMode("list")}
                >
                  <IconList />
                </button>
              </div>
            </div>

            {/* Videos Grid/List */}
            {loadingVideos ? (
              <div style={{ display: viewMode === "grid" ? "grid" : "flex", gridTemplateColumns: "repeat(auto-fill, minmax(260px, 1fr))", gap: 16, flexDirection: "column" }}>
                {Array.from({ length: 12 }).map((_, i) => (
                  <div key={i} className="glass-card" style={{ overflow: "hidden" }}>
                    <div className="skeleton" style={{ paddingTop: "56.25%", width: "100%" }} />
                    <div style={{ padding: 14 }}>
                      <div className="skeleton" style={{ height: 14, marginBottom: 8, width: "90%" }} />
                      <div className="skeleton" style={{ height: 12, width: "60%" }} />
                    </div>
                  </div>
                ))}
              </div>
            ) : filteredVideos.length === 0 ? (
              <div style={{ textAlign: "center", padding: "60px 20px", color: "var(--text-secondary)" }}>
                <div style={{ fontSize: 48, marginBottom: 16 }}>🔍</div>
                <p style={{ fontSize: 16 }}>ویدیویی یافت نشد</p>
              </div>
            ) : (
              <div
                style={{
                  display: viewMode === "grid" ? "grid" : "flex",
                  gridTemplateColumns: viewMode === "grid" ? "repeat(auto-fill, minmax(260px, 1fr))" : undefined,
                  flexDirection: viewMode === "list" ? "column" : undefined,
                  gap: 16,
                }}
              >
                {filteredVideos.map((video, i) => (
                  <div key={video.videoId} className="animate-fade-in" style={{ animationDelay: `${Math.min(i * 30, 300)}ms` }}>
                    <VideoCard video={video} viewMode={viewMode} onSelect={setSelectedVideo} />
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </main>

      {/* ── Connect Modal ─────────────────────────────────────────────────── */}
      {showConnectModal && (
        <div
          onClick={() => !connecting && setShowConnectModal(false)}
          style={{
            position: "fixed", inset: 0, zIndex: 1000,
            background: "rgba(0,0,0,0.7)", backdropFilter: "blur(8px)",
            display: "flex", alignItems: "center", justifyContent: "center", padding: 24,
          }}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="glass-card animate-fade-in"
            style={{ width: "100%", maxWidth: 520, padding: 32 }}
          >
            <div style={{ marginBottom: 24, textAlign: "center" }}>
              <div style={{ fontSize: 40, marginBottom: 12 }}>🔗</div>
              <h2 style={{ fontSize: 22, fontWeight: 800, color: "var(--text-primary)", marginBottom: 8 }}>اتصال به کانال یوتیوب</h2>
              <p style={{ fontSize: 14, color: "var(--text-secondary)", lineHeight: 1.6 }}>
                لینک Share یک ویدیوی کانال مورد نظر را وارد کنید.<br />
                ما به طور خودکار به کانال متصل می‌شویم و همه ویدیوها را می‌آوریم.
              </p>
            </div>

            <div style={{ marginBottom: 20 }}>
              <label style={{ fontSize: 13, fontWeight: 600, color: "var(--text-secondary)", display: "block", marginBottom: 8 }}>
                لینک YouTube ویدیو
              </label>
              <input
                className="input-field"
                placeholder="https://youtu.be/xxxxx یا https://www.youtube.com/watch?v=xxxxx"
                value={youtubeUrl}
                onChange={(e) => setYoutubeUrl(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handleConnect()}
                disabled={connecting}
                dir="ltr"
                style={{ textAlign: "left" }}
              />
              <p style={{ fontSize: 12, color: "var(--text-secondary)", marginTop: 8 }}>
                💡 مثال: <code style={{ background: "rgba(124,58,237,0.1)", padding: "2px 6px", borderRadius: 4 }}>https://youtu.be/dQw4w9WgXcQ</code>
              </p>
            </div>

            <div style={{ display: "flex", gap: 12 }}>
              <button className="btn-primary" style={{ flex: 1, justifyContent: "center", fontSize: 15, padding: "14px" }} onClick={handleConnect} disabled={connecting}>
                {connecting ? (
                  <>
                    <div className="spinner" />
                    در حال اتصال...
                  </>
                ) : (
                  <>
                    <IconLink /> اتصال به کانال
                  </>
                )}
              </button>
              <button className="btn-outline" onClick={() => setShowConnectModal(false)} disabled={connecting}>
                انصراف
              </button>
            </div>

            {/* API Key notice */}
            <div style={{ marginTop: 20, padding: "12px 16px", background: "rgba(124,58,237,0.08)", borderRadius: 10, border: "1px solid rgba(124,58,237,0.2)" }}>
              <p style={{ fontSize: 12, color: "var(--text-secondary)", lineHeight: 1.6 }}>
                ⚙️ <strong style={{ color: "var(--accent-light)" }}>نیاز به YouTube API Key:</strong> برای استفاده، کلید API یوتیوب را در فایل <code style={{ background: "rgba(0,0,0,0.3)", padding: "1px 5px", borderRadius: 4 }}>.env</code> با نام <code style={{ background: "rgba(0,0,0,0.3)", padding: "1px 5px", borderRadius: 4 }}>YOUTUBE_API_KEY</code> تنظیم کنید.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* ── Video Detail Modal ────────────────────────────────────────────── */}
      {selectedVideo && (
        <VideoModal video={selectedVideo} onClose={() => setSelectedVideo(null)} />
      )}

      {/* ── Toasts ───────────────────────────────────────────────────────── */}
      <ToastContainer toasts={toasts} onRemove={(id) => setToasts((prev) => prev.filter((t) => t.id !== id))} />
    </div>
  );
}
