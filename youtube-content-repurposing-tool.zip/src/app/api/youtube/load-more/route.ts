import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { videos } from "@/db/schema";
import { getChannelVideos, getVideosDetails } from "@/lib/youtube";
import { eq } from "drizzle-orm";

export async function POST(req: NextRequest) {
  try {
    const { channelId, pageToken } = await req.json();
    if (!channelId) {
      return NextResponse.json({ error: "channelId is required" }, { status: 400 });
    }

    const searchData = await getChannelVideos(channelId, 50, pageToken);
    const videoIds: string[] = (searchData.items || [])
      .map((item: { id: { videoId: string } }) => item.id.videoId)
      .filter(Boolean);

    const detailedVideos = videoIds.length > 0 ? await getVideosDetails(videoIds) : [];

    for (const v of detailedVideos) {
      const existing = await db
        .select()
        .from(videos)
        .where(eq(videos.videoId, v.id))
        .limit(1);

      const videoRow = {
        channelId,
        videoId: v.id,
        title: v.snippet?.title || "",
        description: v.snippet?.description || "",
        thumbnail:
          v.snippet?.thumbnails?.high?.url ||
          v.snippet?.thumbnails?.medium?.url ||
          v.snippet?.thumbnails?.default?.url ||
          "",
        publishedAt: v.snippet?.publishedAt || "",
        duration: v.contentDetails?.duration || "",
        viewCount: v.statistics?.viewCount || "0",
        likeCount: v.statistics?.likeCount || "0",
        commentCount: v.statistics?.commentCount || "0",
      };

      if (existing.length === 0) {
        await db.insert(videos).values(videoRow);
      } else {
        await db.update(videos).set(videoRow).where(eq(videos.videoId, v.id));
      }
    }

    return NextResponse.json({
      success: true,
      videosCount: detailedVideos.length,
      nextPageToken: searchData.nextPageToken || null,
    });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : "Unknown error";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
