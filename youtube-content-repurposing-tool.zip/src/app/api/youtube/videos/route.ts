import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { videos } from "@/db/schema";
import { eq, desc } from "drizzle-orm";

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const channelId = searchParams.get("channelId");

    let allVideos;
    if (channelId) {
      allVideos = await db
        .select()
        .from(videos)
        .where(eq(videos.channelId, channelId))
        .orderBy(desc(videos.savedAt));
    } else {
      allVideos = await db.select().from(videos).orderBy(desc(videos.savedAt));
    }

    return NextResponse.json({ videos: allVideos });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : "Unknown error";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
