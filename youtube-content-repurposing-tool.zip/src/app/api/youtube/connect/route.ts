import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { channels, videos } from "@/db/schema";
import {
  extractVideoId,
  getVideoDetails,
  getChannelDetails,
  getChannelVideos,
  getVideosDetails,
} from "@/lib/youtube";
import { eq } from "drizzle-orm";

export async function POST(req: NextRequest) {
  try {
    const { url } = await req.json();
    if (!url) {
      return NextResponse.json({ error: "URL is required" }, { status: 400 });
    }

    // Check API key
    if (!process.env.YOUTUBE_API_KEY) {
      return NextResponse.json(
        { error: "YouTube API key not configured. Please add YOUTUBE_API_KEY to your .env file." },
        { status: 500 }
      );
    }

    // Extract video ID from URL
    const videoId = extractVideoId(url.trim());
    if (!videoId) {
      return NextResponse.json({ error: "Invalid YouTube URL" }, { status: 400 });
    }

    // Get video info to find channel ID
    const videoData = await getVideoDetails(videoId);
    const channelId = videoData.snippet.channelId;

    // Get channel details
    const channelData = await getChannelDetails(channelId);
    const snippet = channelData.snippet;
    const stats = channelData.statistics;

    // Save channel to DB
    const existingChannel = await db
      .select()
      .from(channels)
      .where(eq(channels.channelId, channelId))
      .limit(1);

    if (existingChannel.length === 0) {
      await db.insert(channels).values({
        channelId,
        channelTitle: snippet.title,
        description: snippet.description || "",
        thumbnail: snippet.thumbnails?.high?.url || snippet.thumbnails?.default?.url || "",
        subscriberCount: stats?.subscriberCount || "0",
        videoCount: stats?.videoCount || "0",
        viewCount: stats?.viewCount || "0",
      });
    } else {
      await db
        .update(channels)
        .set({
          channelTitle: snippet.title,
          description: snippet.description || "",
          thumbnail: snippet.thumbnails?.high?.url || snippet.thumbnails?.default?.url || "",
          subscriberCount: stats?.subscriberCount || "0",
          videoCount: stats?.videoCount || "0",
          viewCount: stats?.viewCount || "0",
        })
        .where(eq(channels.channelId, channelId));
    }

    // Fetch videos from the channel (up to 50)
    const searchData = await getChannelVideos(channelId, 50);
    const videoIds: string[] = (searchData.items || [])
      .map((item: { id: { videoId: string } }) => item.id.videoId)
      .filter(Boolean);

    // Get detailed info for all videos
    const detailedVideos = videoIds.length > 0 ? await getVideosDetails(videoIds) : [];

    // Save videos to DB
    for (const v of detailedVideos) {
      const existing = await db
        .select()
        .from(videos)
        .where(eq(videos.videoId, v.id))
        .limit(1);

      const videoRow = {
        channelId,
        videoId: v.id,
        title: v.snippet?.title || "",
        description: v.snippet?.description || "",
        thumbnail:
          v.snippet?.thumbnails?.high?.url ||
          v.snippet?.thumbnails?.medium?.url ||
          v.snippet?.thumbnails?.default?.url ||
          "",
        publishedAt: v.snippet?.publishedAt || "",
        duration: v.contentDetails?.duration || "",
        viewCount: v.statistics?.viewCount || "0",
        likeCount: v.statistics?.likeCount || "0",
        commentCount: v.statistics?.commentCount || "0",
      };

      if (existing.length === 0) {
        await db.insert(videos).values(videoRow);
      } else {
        await db.update(videos).set(videoRow).where(eq(videos.videoId, v.id));
      }
    }

    return NextResponse.json({
      success: true,
      channel: {
        channelId,
        channelTitle: snippet.title,
        description: snippet.description,
        thumbnail: snippet.thumbnails?.high?.url || snippet.thumbnails?.default?.url,
        subscriberCount: stats?.subscriberCount || "0",
        videoCount: stats?.videoCount || "0",
        viewCount: stats?.viewCount || "0",
      },
      videosCount: detailedVideos.length,
      nextPageToken: searchData.nextPageToken,
    });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : "Unknown error";
    console.error("Connect error:", message);
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
