import { NextResponse } from "next/server";
import { db } from "@/db";
import { channels } from "@/db/schema";

export async function GET() {
  try {
    const allChannels = await db.select().from(channels).orderBy(channels.addedAt);
    return NextResponse.json({ channels: allChannels });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : "Unknown error";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
