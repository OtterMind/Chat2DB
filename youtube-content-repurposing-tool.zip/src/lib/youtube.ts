const YOUTUBE_API_KEY = process.env.YOUTUBE_API_KEY;
const BASE_URL = "https://www.googleapis.com/youtube/v3";

export function extractVideoId(url: string): string | null {
  const patterns = [
    /(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/|youtube\.com\/shorts\/)([a-zA-Z0-9_-]{11})/,
    /^([a-zA-Z0-9_-]{11})$/,
  ];
  for (const pattern of patterns) {
    const match = url.match(pattern);
    if (match) return match[1];
  }
  return null;
}

export async function getVideoDetails(videoId: string) {
  if (!YOUTUBE_API_KEY) throw new Error("YouTube API key not configured");
  const url = `${BASE_URL}/videos?part=snippet,contentDetails,statistics&id=${videoId}&key=${YOUTUBE_API_KEY}`;
  const res = await fetch(url);
  if (!res.ok) throw new Error(`YouTube API error: ${res.statusText}`);
  const data = await res.json();
  if (!data.items || data.items.length === 0) throw new Error("Video not found");
  return data.items[0];
}

export async function getChannelDetails(channelId: string) {
  if (!YOUTUBE_API_KEY) throw new Error("YouTube API key not configured");
  const url = `${BASE_URL}/channels?part=snippet,statistics,contentDetails&id=${channelId}&key=${YOUTUBE_API_KEY}`;
  const res = await fetch(url);
  if (!res.ok) throw new Error(`YouTube API error: ${res.statusText}`);
  const data = await res.json();
  if (!data.items || data.items.length === 0) throw new Error("Channel not found");
  return data.items[0];
}

export async function getChannelVideos(channelId: string, maxResults = 50, pageToken?: string) {
  if (!YOUTUBE_API_KEY) throw new Error("YouTube API key not configured");
  let url = `${BASE_URL}/search?part=snippet&channelId=${channelId}&maxResults=${maxResults}&order=date&type=video&key=${YOUTUBE_API_KEY}`;
  if (pageToken) url += `&pageToken=${pageToken}`;
  const res = await fetch(url);
  if (!res.ok) throw new Error(`YouTube API error: ${res.statusText}`);
  const data = await res.json();
  return data;
}

export async function getVideosDetails(videoIds: string[]) {
  if (!YOUTUBE_API_KEY) throw new Error("YouTube API key not configured");
  const ids = videoIds.join(",");
  const url = `${BASE_URL}/videos?part=snippet,contentDetails,statistics&id=${ids}&key=${YOUTUBE_API_KEY}`;
  const res = await fetch(url);
  if (!res.ok) throw new Error(`YouTube API error: ${res.statusText}`);
  const data = await res.json();
  return data.items || [];
}

export function formatDuration(iso: string): string {
  if (!iso) return "0:00";
  const match = iso.match(/PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?/);
  if (!match) return "0:00";
  const h = parseInt(match[1] || "0");
  const m = parseInt(match[2] || "0");
  const s = parseInt(match[3] || "0");
  if (h > 0) return `${h}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
  return `${m}:${String(s).padStart(2, "0")}`;
}

export function formatCount(count: string | number): string {
  const n = typeof count === "string" ? parseInt(count) : count;
  if (isNaN(n)) return "0";
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(1)}M`;
  if (n >= 1_000) return `${(n / 1_000).toFixed(1)}K`;
  return n.toString();
}
