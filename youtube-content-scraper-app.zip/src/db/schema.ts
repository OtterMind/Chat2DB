import {
  pgTable,
  text,
  integer,
  timestamp,
  boolean,
  jsonb,
  serial,
  varchar,
} from "drizzle-orm/pg-core";

// ─── Channels ────────────────────────────────────────────────────────────────
export const channels = pgTable("channels", {
  id: serial("id").primaryKey(),
  channelId: varchar("channel_id", { length: 255 }).notNull().unique(),
  channelName: text("channel_name").notNull(),
  channelUrl: text("channel_url").notNull(),
  thumbnailUrl: text("thumbnail_url"),
  description: text("description"),
  subscriberCount: integer("subscriber_count"),
  videoCount: integer("video_count"),
  totalClips: integer("total_clips").default(0),
  isActive: boolean("is_active").default(true),
  lastSyncedAt: timestamp("last_synced_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ─── Videos ──────────────────────────────────────────────────────────────────
export const videos = pgTable("videos", {
  id: serial("id").primaryKey(),
  channelId: integer("channel_id")
    .references(() => channels.id, { onDelete: "cascade" })
    .notNull(),
  videoId: varchar("video_id", { length: 255 }).notNull().unique(),
  title: text("title").notNull(),
  description: text("description"),
  thumbnailUrl: text("thumbnail_url"),
  duration: integer("duration"), // seconds
  viewCount: integer("view_count"),
  likeCount: integer("like_count"),
  commentCount: integer("comment_count"),
  publishedAt: timestamp("published_at"),
  transcriptFetched: boolean("transcript_fetched").default(false),
  clipsGenerated: boolean("clips_generated").default(false),
  status: varchar("status", { length: 50 }).default("pending"), // pending | processing | done | error
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ─── Transcripts ──────────────────────────────────────────────────────────────
export const transcripts = pgTable("transcripts", {
  id: serial("id").primaryKey(),
  videoId: integer("video_id")
    .references(() => videos.id, { onDelete: "cascade" })
    .notNull()
    .unique(),
  fullText: text("full_text"),
  segments: jsonb("segments"), // [{text, start, duration}]
  language: varchar("language", { length: 10 }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ─── Clips ────────────────────────────────────────────────────────────────────
export const clips = pgTable("clips", {
  id: serial("id").primaryKey(),
  videoId: integer("video_id")
    .references(() => videos.id, { onDelete: "cascade" })
    .notNull(),
  channelId: integer("channel_id")
    .references(() => channels.id, { onDelete: "cascade" })
    .notNull(),
  title: text("title").notNull(),
  description: text("description"),
  startTime: integer("start_time").notNull(), // seconds
  endTime: integer("end_time").notNull(), // seconds
  duration: integer("duration").notNull(), // seconds
  viralScore: integer("viral_score"), // 0-100
  reason: text("reason"), // why AI thinks this is viral
  transcript: text("transcript"), // clip's transcript text
  format: varchar("format", { length: 20 }).default("vertical"), // vertical | square
  status: varchar("status", { length: 50 }).default("ready"), // ready | posted | archived
  platforms: jsonb("platforms"), // {tiktok: bool, instagram: bool, youtube: bool, facebook: bool}
  postedAt: timestamp("posted_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ─── Settings ─────────────────────────────────────────────────────────────────
export const settings = pgTable("settings", {
  id: serial("id").primaryKey(),
  key: varchar("key", { length: 100 }).notNull().unique(),
  value: text("value"),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// ─── Types ────────────────────────────────────────────────────────────────────
export type Channel = typeof channels.$inferSelect;
export type NewChannel = typeof channels.$inferInsert;
export type Video = typeof videos.$inferSelect;
export type NewVideo = typeof videos.$inferInsert;
export type Transcript = typeof transcripts.$inferSelect;
export type Clip = typeof clips.$inferSelect;
export type NewClip = typeof clips.$inferInsert;
