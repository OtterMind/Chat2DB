"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import StatCard from "@/components/StatCard";
import {
  Scissors,
  ListVideo,
  BarChart3,
  CheckCircle,
  Clock,
  Zap,
  ArrowRight,
  Plus,
} from "lucide-react";
import { formatDuration, viralScoreColor, viralScoreBg, timeAgo } from "@/lib/utils";
import { cn } from "@/lib/utils";
import AddChannelModal from "@/components/AddChannelModal";

interface Stats {
  channels: number;
  videos: number;
  clips: number;
  postedClips: number;
  readyClips: number;
  recentClips: Array<{
    id: number;
    title: string;
    duration: number;
    viralScore: number;
    status: string;
    createdAt: string;
  }>;
}

export default function DashboardPage() {
  const [stats, setStats] = useState<Stats | null>(null);
  const [loading, setLoading] = useState(true);
  const [showAdd, setShowAdd] = useState(false);
  const [seeding, setSeeding] = useState(false);

  const loadStats = async () => {
    const res = await fetch("/api/stats");
    const data = await res.json();
    setStats(data);
    setLoading(false);
  };

  const seedDemo = async () => {
    setSeeding(true);
    await fetch("/api/demo/seed", { method: "POST" });
    await loadStats();
    setSeeding(false);
  };

  useEffect(() => {
    loadStats();
  }, []);

  const isEmpty = stats && stats.channels === 0;

  return (
    <div className="p-8 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex items-start justify-between mb-8">
        <div>
          <h1 className="text-3xl font-bold text-white">Dashboard</h1>
          <p className="text-gray-400 mt-1">
            Your AI-powered YouTube → Shorts automation hub
          </p>
        </div>
        <div className="flex items-center gap-3">
          <button
            onClick={seedDemo}
            disabled={seeding}
            className="text-sm text-gray-400 hover:text-gray-200 border border-gray-700 hover:border-gray-600 px-4 py-2 rounded-xl transition-colors disabled:opacity-50"
          >
            {seeding ? "Loading..." : "Load Demo Data"}
          </button>
          <button
            onClick={() => setShowAdd(true)}
            className="flex items-center gap-2 bg-violet-600 hover:bg-violet-500 text-white text-sm font-semibold px-4 py-2 rounded-xl transition-colors"
          >
            <Plus className="w-4 h-4" />
            Add Channel
          </button>
        </div>
      </div>

      {/* Welcome banner for empty state */}
      {isEmpty && !loading && (
        <div className="mb-8 bg-gradient-to-r from-violet-900/40 to-indigo-900/40 border border-violet-700/30 rounded-2xl p-8">
          <div className="max-w-2xl">
            <div className="flex items-center gap-2 mb-3">
              <Zap className="w-5 h-5 text-yellow-400" />
              <span className="text-yellow-400 font-semibold text-sm uppercase tracking-wide">
                Welcome to EasyClip.AI
              </span>
            </div>
            <h2 className="text-2xl font-bold text-white mb-2">
              Turn YouTube Videos into Viral Shorts
            </h2>
            <p className="text-gray-300 mb-6">
              Connect a YouTube channel, and our AI will automatically detect viral moments,
              generate short clips, and help you distribute them across TikTok, Instagram Reels,
              and YouTube Shorts — with zero editing required.
            </p>
            <div className="flex items-center gap-4">
              <button
                onClick={() => setShowAdd(true)}
                className="flex items-center gap-2 bg-violet-600 hover:bg-violet-500 text-white font-semibold px-6 py-3 rounded-xl transition-colors"
              >
                <Plus className="w-4 h-4" />
                Connect Your First Channel
              </button>
              <button
                onClick={seedDemo}
                disabled={seeding}
                className="text-violet-400 hover:text-violet-300 text-sm flex items-center gap-1 transition-colors"
              >
                or load demo data
                <ArrowRight className="w-3 h-3" />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Stats grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <StatCard
          title="Channels Connected"
          value={loading ? "—" : stats?.channels ?? 0}
          icon={ListVideo}
          color="violet"
          subtitle="YouTube channels"
        />
        <StatCard
          title="Videos Fetched"
          value={loading ? "—" : stats?.videos ?? 0}
          icon={BarChart3}
          color="blue"
          subtitle="from connected channels"
        />
        <StatCard
          title="Clips Generated"
          value={loading ? "—" : stats?.clips ?? 0}
          icon={Scissors}
          color="green"
          subtitle="AI-powered short clips"
        />
        <StatCard
          title="Clips Posted"
          value={loading ? "—" : stats?.postedClips ?? 0}
          icon={CheckCircle}
          color="orange"
          subtitle="across all platforms"
        />
      </div>

      {/* How it works */}
      <div className="mb-8 grid grid-cols-3 gap-4">
        {[
          {
            step: "01",
            icon: ListVideo,
            title: "Connect Channel",
            desc: "Paste any YouTube video or channel URL to connect.",
            color: "text-violet-400",
            href: "/channels",
          },
          {
            step: "02",
            icon: Zap,
            title: "AI Analyzes Videos",
            desc: "AI scans transcripts and finds viral moments automatically.",
            color: "text-yellow-400",
            href: "/channels",
          },
          {
            step: "03",
            icon: Scissors,
            title: "Get Viral Clips",
            desc: "Download clips with timestamps for Shorts, Reels & TikTok.",
            color: "text-green-400",
            href: "/clips",
          },
        ].map(({ step, icon: Icon, title, desc, color, href }) => (
          <Link key={step} href={href}>
            <div className="bg-gray-900 border border-gray-800 hover:border-gray-700 rounded-2xl p-6 transition-colors cursor-pointer group">
              <div className="flex items-start gap-4">
                <div className="text-gray-700 font-mono font-bold text-2xl">{step}</div>
                <div>
                  <Icon className={cn("w-5 h-5 mb-2", color)} />
                  <h3 className="text-white font-semibold mb-1">{title}</h3>
                  <p className="text-gray-400 text-sm leading-relaxed">{desc}</p>
                </div>
              </div>
            </div>
          </Link>
        ))}
      </div>

      {/* Recent clips */}
      {stats && stats.recentClips.length > 0 && (
        <div>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-white font-bold text-lg">Recent Clips</h2>
            <Link
              href="/clips"
              className="text-violet-400 hover:text-violet-300 text-sm flex items-center gap-1 transition-colors"
            >
              View all
              <ArrowRight className="w-3 h-3" />
            </Link>
          </div>
          <div className="space-y-3">
            {stats.recentClips.map((clip) => (
              <div
                key={clip.id}
                className="bg-gray-900 border border-gray-800 rounded-xl p-4 flex items-center gap-4"
              >
                {/* Viral score */}
                <div
                  className={cn(
                    "w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0 font-bold text-sm",
                    viralScoreBg(clip.viralScore || 0),
                    "text-white"
                  )}
                >
                  {clip.viralScore}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-white text-sm font-medium truncate">{clip.title}</p>
                  <div className="flex items-center gap-3 text-xs text-gray-500 mt-1">
                    <span className="flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {formatDuration(clip.duration)}
                    </span>
                    <span className="flex items-center gap-1">
                      <Zap className="w-3 h-3" />
                      <span className={viralScoreColor(clip.viralScore || 0)}>
                        Score: {clip.viralScore}
                      </span>
                    </span>
                    <span>{timeAgo(clip.createdAt)}</span>
                  </div>
                </div>
                <span
                  className={cn(
                    "text-xs font-semibold px-2.5 py-1 rounded-lg border uppercase tracking-wide",
                    clip.status === "posted"
                      ? "bg-green-500/20 text-green-300 border-green-600/30"
                      : clip.status === "archived"
                      ? "bg-gray-500/20 text-gray-400 border-gray-600/30"
                      : "bg-blue-500/20 text-blue-300 border-blue-600/30"
                  )}
                >
                  {clip.status}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {showAdd && (
        <AddChannelModal
          onClose={() => setShowAdd(false)}
          onSuccess={() => loadStats()}
        />
      )}
    </div>
  );
}
