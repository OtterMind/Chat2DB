"use client";
import { useEffect, useState, Suspense } from "react";
import { useSearchParams } from "next/navigation";
import ClipCard from "@/components/ClipCard";
import {
  Scissors,
  Filter,
  SortDesc,
} from "lucide-react";
import { cn } from "@/lib/utils";

interface ClipRow {
  clip: {
    id: number;
    title: string;
    description: string | null;
    startTime: number;
    endTime: number;
    duration: number;
    viralScore: number | null;
    reason: string | null;
    transcript: string | null;
    status: string | null;
    platforms: Record<string, boolean> | null;
    createdAt: string;
  };
  video: {
    videoId: string;
    title: string;
    thumbnailUrl: string | null;
    duration: number | null;
  } | null;
  channel: {
    channelName: string;
    channelId: string;
  } | null;
}

type FilterStatus = "all" | "ready" | "posted" | "archived";
type SortBy = "newest" | "score" | "duration";

function ClipsContent() {
  const searchParams = useSearchParams();
  const videoIdParam = searchParams.get("videoId");
  const [clips, setClips] = useState<ClipRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<FilterStatus>("all");
  const [sort, setSort] = useState<SortBy>("newest");

  const loadClips = async () => {
    const url = videoIdParam
      ? `/api/clips?videoId=${videoIdParam}`
      : "/api/clips";
    const res = await fetch(url);
    const data = await res.json();
    setClips(data.clips || []);
    setLoading(false);
  };

  useEffect(() => {
    loadClips();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [videoIdParam]);

  const handleDelete = (id: number) => {
    setClips((prev) => prev.filter((c) => c.clip.id !== id));
  };

  const handleStatusChange = (id: number, status: string) => {
    setClips((prev) =>
      prev.map((c) =>
        c.clip.id === id ? { ...c, clip: { ...c.clip, status } } : c
      )
    );
  };

  const filtered = clips
    .filter((c) => filter === "all" || c.clip.status === filter)
    .sort((a, b) => {
      if (sort === "score") return (b.clip.viralScore || 0) - (a.clip.viralScore || 0);
      if (sort === "duration") return (b.clip.duration || 0) - (a.clip.duration || 0);
      return new Date(b.clip.createdAt).getTime() - new Date(a.clip.createdAt).getTime();
    });

  const counts: Record<FilterStatus, number> = {
    all: clips.length,
    ready: clips.filter((c) => c.clip.status === "ready").length,
    posted: clips.filter((c) => c.clip.status === "posted").length,
    archived: clips.filter((c) => c.clip.status === "archived").length,
  };

  const filters: { key: FilterStatus; label: string }[] = [
    { key: "all", label: "All" },
    { key: "ready", label: "Ready" },
    { key: "posted", label: "Posted" },
    { key: "archived", label: "Archived" },
  ];

  return (
    <div className="p-8 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex items-start justify-between mb-6">
        <div>
          <h1 className="text-3xl font-bold text-white">AI Clips</h1>
          <p className="text-gray-400 mt-1">
            {clips.length} clips generated across all channels
          </p>
        </div>
      </div>

      {/* Filters + Sort bar */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-2 bg-gray-900 border border-gray-800 rounded-xl p-1">
          {filters.map(({ key, label }) => (
            <button
              key={key}
              onClick={() => setFilter(key)}
              className={cn(
                "px-4 py-1.5 rounded-lg text-sm font-medium transition-all",
                filter === key
                  ? "bg-violet-600 text-white"
                  : "text-gray-400 hover:text-gray-200"
              )}
            >
              {label}
              <span className={cn("ml-1.5 text-xs", filter === key ? "text-violet-200" : "text-gray-600")}>
                {counts[key]}
              </span>
            </button>
          ))}
        </div>

        <div className="flex items-center gap-2">
          <Filter className="w-4 h-4 text-gray-500" />
          <SortDesc className="w-4 h-4 text-gray-500" />
          <select
            value={sort}
            onChange={(e) => setSort(e.target.value as SortBy)}
            className="bg-gray-900 border border-gray-800 text-gray-300 text-sm rounded-xl px-3 py-2 focus:outline-none focus:border-violet-500"
          >
            <option value="newest">Newest First</option>
            <option value="score">Highest Viral Score</option>
            <option value="duration">Longest Duration</option>
          </select>
        </div>
      </div>

      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {[1, 2, 3, 4, 5, 6].map((i) => (
            <div
              key={i}
              className="bg-gray-900 border border-gray-800 rounded-2xl animate-pulse"
            >
              <div className="aspect-video bg-gray-800" />
              <div className="p-4 space-y-2">
                <div className="h-4 bg-gray-800 rounded" />
                <div className="h-3 bg-gray-800 rounded w-3/4" />
              </div>
            </div>
          ))}
        </div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-24">
          <Scissors className="w-14 h-14 text-gray-700 mx-auto mb-4" />
          <h2 className="text-xl font-semibold text-gray-400 mb-2">
            {clips.length === 0 ? "No clips yet" : `No ${filter} clips`}
          </h2>
          <p className="text-gray-600">
            {clips.length === 0
              ? "Go to Channels, select a video, and click Generate Clips"
              : "Try a different filter"}
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {filtered.map((row) => (
            <ClipCard
              key={row.clip.id}
              clip={row.clip}
              videoId={row.video?.videoId}
              videoTitle={row.video?.title}
              thumbnailUrl={row.video?.thumbnailUrl || undefined}
              onDelete={handleDelete}
              onStatusChange={handleStatusChange}
            />
          ))}
        </div>
      )}
    </div>
  );
}

export default function ClipsPage() {
  return (
    <Suspense
      fallback={
        <div className="p-8">
          <div className="animate-pulse space-y-4">
            <div className="h-8 bg-gray-800 rounded w-1/3" />
            <div className="grid grid-cols-4 gap-4">
              {[1, 2, 3, 4].map((i) => (
                <div key={i} className="bg-gray-900 border border-gray-800 rounded-2xl h-64" />
              ))}
            </div>
          </div>
        </div>
      }
    >
      <ClipsContent />
    </Suspense>
  );
}
