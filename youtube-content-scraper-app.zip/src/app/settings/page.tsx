"use client";
import { useState } from "react";
import {
  Key,
  CheckCircle2,
  AlertCircle,
  Info,
  ExternalLink,
  Zap,
  Globe,
  Shield,
} from "lucide-react";

interface ApiStatus {
  youtube: boolean | null;
  openai: boolean | null;
}

export default function SettingsPage() {
  const [apiStatus] = useState<ApiStatus>({ youtube: null, openai: null });

  const envCards = [
    {
      key: "YOUTUBE_API_KEY",
      icon: "▶️",
      title: "YouTube Data API v3",
      description:
        "Required to fetch channel info, video lists, and metadata. Get it from Google Cloud Console.",
      docsUrl: "https://console.cloud.google.com/apis/library/youtube.googleapis.com",
      status: apiStatus.youtube,
      color: "border-red-800/30 bg-red-950/20",
      iconBg: "bg-red-900/30 text-red-400",
      features: [
        "Fetch channel info from URL",
        "Get video metadata & thumbnails",
        "Sync latest uploads automatically",
        "View subscriber & view counts",
      ],
    },
    {
      key: "OPENAI_API_KEY",
      icon: "🤖",
      title: "OpenAI API (GPT-4o-mini)",
      description:
        "Powers the AI viral moment detection and clip title/description generation.",
      docsUrl: "https://platform.openai.com/api-keys",
      status: apiStatus.openai,
      color: "border-green-800/30 bg-green-950/20",
      iconBg: "bg-green-900/30 text-green-400",
      features: [
        "AI viral moment detection",
        "Smart clip title generation",
        "TikTok caption writing",
        "Viral score prediction (0-100)",
      ],
    },
  ];

  const howToSteps = [
    {
      step: "1",
      title: "Add to .env file",
      code: "YOUTUBE_API_KEY=AIza...\nOPENAI_API_KEY=sk-...",
      desc: "Add your API keys to the .env file in the project root.",
    },
    {
      step: "2",
      title: "Restart the server",
      code: "npm run dev",
      desc: "Restart the development server for environment variables to take effect.",
    },
    {
      step: "3",
      title: "Connect a channel",
      code: "Go to Channels → Add Channel",
      desc: "Paste any YouTube video or channel URL to get started.",
    },
  ];

  return (
    <div className="p-8 max-w-4xl mx-auto">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-white">Settings</h1>
        <p className="text-gray-400 mt-1">Configure API keys and platform connections</p>
      </div>

      {/* Current mode banner */}
      <div className="mb-8 bg-blue-950/30 border border-blue-800/30 rounded-2xl p-5 flex items-start gap-4">
        <Info className="w-5 h-5 text-blue-400 flex-shrink-0 mt-0.5" />
        <div>
          <h3 className="text-blue-300 font-semibold mb-1">Demo Mode Active</h3>
          <p className="text-gray-400 text-sm leading-relaxed">
            The app runs in demo mode without API keys. Add your keys to unlock real YouTube
            channel connections and true AI-powered clip generation. In demo mode, clips are
            generated with placeholder AI analysis.
          </p>
        </div>
      </div>

      {/* API Keys */}
      <div className="space-y-4 mb-8">
        <h2 className="text-white font-bold text-lg">Required API Keys</h2>
        {envCards.map((card) => (
          <div
            key={card.key}
            className={`border rounded-2xl p-6 ${card.color}`}
          >
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center gap-3">
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center text-xl ${card.iconBg}`}>
                  {card.icon}
                </div>
                <div>
                  <h3 className="text-white font-bold">{card.title}</h3>
                  <code className="text-gray-500 text-xs font-mono">{card.key}</code>
                </div>
              </div>
              <a
                href={card.docsUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-1 text-gray-400 hover:text-gray-200 text-xs transition-colors"
              >
                Get API Key
                <ExternalLink className="w-3 h-3" />
              </a>
            </div>
            <p className="text-gray-400 text-sm mb-4">{card.description}</p>
            <div className="grid grid-cols-2 gap-2">
              {card.features.map((f) => (
                <div key={f} className="flex items-center gap-2 text-xs text-gray-400">
                  <CheckCircle2 className="w-3.5 h-3.5 text-green-500 flex-shrink-0" />
                  {f}
                </div>
              ))}
            </div>
            <div className="mt-4 bg-gray-900/60 rounded-xl p-3 font-mono text-xs text-gray-300">
              <span className="text-gray-600"># Add to .env file:</span>
              <br />
              <span className="text-violet-400">{card.key}</span>
              <span className="text-gray-400">=</span>
              <span className="text-green-400">your_api_key_here</span>
            </div>
          </div>
        ))}
      </div>

      {/* How to setup */}
      <div className="mb-8">
        <h2 className="text-white font-bold text-lg mb-4">Setup Guide</h2>
        <div className="space-y-3">
          {howToSteps.map(({ step, title, code, desc }) => (
            <div key={step} className="bg-gray-900 border border-gray-800 rounded-2xl p-5 flex gap-4">
              <div className="w-8 h-8 bg-violet-600 rounded-lg flex items-center justify-center text-white font-bold text-sm flex-shrink-0">
                {step}
              </div>
              <div>
                <h3 className="text-white font-semibold mb-1">{title}</h3>
                <p className="text-gray-500 text-sm mb-2">{desc}</p>
                <code className="text-green-400 text-xs font-mono bg-gray-800 px-3 py-1.5 rounded-lg block whitespace-pre">
                  {code}
                </code>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Platform connections (UI only) */}
      <div className="mb-8">
        <h2 className="text-white font-bold text-lg mb-4">Social Platform Auto-Posting</h2>
        <div className="grid grid-cols-2 gap-4">
          {[
            { name: "TikTok", icon: "🎵", color: "border-pink-800/30 bg-pink-950/10" },
            { name: "Instagram Reels", icon: "📸", color: "border-purple-800/30 bg-purple-950/10" },
            { name: "YouTube Shorts", icon: "▶️", color: "border-red-800/30 bg-red-950/10" },
            { name: "Facebook Reels", icon: "👍", color: "border-blue-800/30 bg-blue-950/10" },
          ].map(({ name, icon, color }) => (
            <div key={name} className={`border rounded-2xl p-5 ${color}`}>
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-3">
                  <span className="text-2xl">{icon}</span>
                  <span className="text-white font-semibold">{name}</span>
                </div>
                <span className="text-xs text-gray-500 bg-gray-800 border border-gray-700 px-2 py-1 rounded-lg">
                  Coming Soon
                </span>
              </div>
              <p className="text-gray-500 text-xs">
                Auto-post generated clips directly to {name}.
              </p>
            </div>
          ))}
        </div>
      </div>

      {/* Feature flags */}
      <div>
        <h2 className="text-white font-bold text-lg mb-4">Features</h2>
        <div className="bg-gray-900 border border-gray-800 rounded-2xl divide-y divide-gray-800">
          {[
            {
              icon: Zap,
              title: "AI Viral Score",
              desc: "Score clips 0-100 based on viral potential",
              enabled: true,
            },
            {
              icon: Globe,
              title: "Multi-Platform Support",
              desc: "Target TikTok, Instagram, YouTube, Facebook",
              enabled: true,
            },
            {
              icon: Shield,
              title: "Demo Mode",
              desc: "Generate sample clips without API keys",
              enabled: true,
            },
            {
              icon: Key,
              title: "Real AI Clip Generation",
              desc: "Requires OpenAI API key",
              enabled: !!process.env.NEXT_PUBLIC_HAS_OPENAI,
            },
          ].map(({ icon: Icon, title, desc, enabled }) => (
            <div key={title} className="flex items-center justify-between p-4">
              <div className="flex items-center gap-3">
                <Icon className="w-4 h-4 text-gray-500" />
                <div>
                  <p className="text-white text-sm font-medium">{title}</p>
                  <p className="text-gray-500 text-xs">{desc}</p>
                </div>
              </div>
              <div className={`w-9 h-5 rounded-full flex items-center px-1 transition-colors ${enabled ? "bg-violet-600" : "bg-gray-700"}`}>
                <div className={`w-3 h-3 bg-white rounded-full transition-transform ${enabled ? "translate-x-4" : "translate-x-0"}`} />
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Warning */}
      <div className="mt-6 bg-yellow-950/20 border border-yellow-800/30 rounded-2xl p-4 flex gap-3">
        <AlertCircle className="w-5 h-5 text-yellow-400 flex-shrink-0 mt-0.5" />
        <div>
          <h3 className="text-yellow-300 font-semibold text-sm mb-1">Important Notes</h3>
          <ul className="text-gray-400 text-xs space-y-1 list-disc ml-3">
            <li>YouTube API has a daily quota of 10,000 units. Each channel sync uses ~100 units.</li>
            <li>Transcripts require videos to have captions enabled (auto-generated counts).</li>
            <li>OpenAI API charges per token. GPT-4o-mini is very affordable (~$0.02 per 5 videos).</li>
            <li>Always respect YouTube&apos;s Terms of Service when repurposing content.</li>
          </ul>
        </div>
      </div>
    </div>
  );
}
