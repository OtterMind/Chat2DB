"use client";
import { useEffect, useState } from "react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Legend,
} from "recharts";
import StatCard from "@/components/StatCard";
import {
  Scissors,
  CheckCircle,
  TrendingUp,
  Clock,
  BarChart3,
} from "lucide-react";

interface Stats {
  channels: number;
  videos: number;
  clips: number;
  postedClips: number;
  readyClips: number;
}

interface ClipRow {
  clip: {
    id: number;
    viralScore: number | null;
    duration: number | null;
    status: string | null;
    createdAt: string;
    platforms: Record<string, boolean> | null;
  };
  channel: { channelName: string } | null;
}

const COLORS = ["#7c3aed", "#4f46e5", "#0ea5e9", "#10b981", "#f59e0b"];

export default function AnalyticsPage() {
  const [stats, setStats] = useState<Stats | null>(null);
  const [clips, setClips] = useState<ClipRow[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([fetch("/api/stats"), fetch("/api/clips")]).then(
      async ([sRes, cRes]) => {
        setStats(await sRes.json());
        const cData = await cRes.json();
        setClips(cData.clips || []);
        setLoading(false);
      }
    );
  }, []);

  // Score distribution
  const scoreData = [
    { range: "0-20", count: 0 },
    { range: "21-40", count: 0 },
    { range: "41-60", count: 0 },
    { range: "61-80", count: 0 },
    { range: "81-100", count: 0 },
  ];
  clips.forEach((c) => {
    const s = c.clip.viralScore || 0;
    if (s <= 20) scoreData[0].count++;
    else if (s <= 40) scoreData[1].count++;
    else if (s <= 60) scoreData[2].count++;
    else if (s <= 80) scoreData[3].count++;
    else scoreData[4].count++;
  });

  // Status distribution for pie
  const statusData = [
    { name: "Ready", value: clips.filter((c) => c.clip.status === "ready").length, color: "#4f46e5" },
    { name: "Posted", value: clips.filter((c) => c.clip.status === "posted").length, color: "#10b981" },
    { name: "Archived", value: clips.filter((c) => c.clip.status === "archived").length, color: "#6b7280" },
  ].filter((d) => d.value > 0);

  // Platform breakdown
  const platformCounts: Record<string, number> = {
    tiktok: 0,
    instagram: 0,
    youtube: 0,
    facebook: 0,
  };
  clips.forEach((c) => {
    if (c.clip.platforms) {
      Object.entries(c.clip.platforms).forEach(([k, v]) => {
        if (v && k in platformCounts) platformCounts[k]++;
      });
    }
  });
  const platformData = Object.entries(platformCounts).map(([name, count]) => ({
    name: name.charAt(0).toUpperCase() + name.slice(1),
    count,
  }));

  // Avg viral score
  const avgScore =
    clips.length > 0
      ? Math.round(
          clips.reduce((sum, c) => sum + (c.clip.viralScore || 0), 0) / clips.length
        )
      : 0;

  // Avg duration
  const avgDuration =
    clips.length > 0
      ? Math.round(
          clips.reduce((sum, c) => sum + (c.clip.duration || 0), 0) / clips.length
        )
      : 0;

  if (loading) {
    return (
      <div className="p-8 max-w-7xl mx-auto">
        <div className="animate-pulse space-y-6">
          <div className="h-8 bg-gray-800 rounded w-1/3" />
          <div className="grid grid-cols-4 gap-4">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="h-32 bg-gray-900 border border-gray-800 rounded-2xl" />
            ))}
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="h-72 bg-gray-900 border border-gray-800 rounded-2xl" />
            <div className="h-72 bg-gray-900 border border-gray-800 rounded-2xl" />
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-8 max-w-7xl mx-auto">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-white">Analytics</h1>
        <p className="text-gray-400 mt-1">Performance insights across all your clips</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <StatCard title="Total Clips" value={stats?.clips ?? 0} icon={Scissors} color="violet" />
        <StatCard title="Posted" value={stats?.postedClips ?? 0} icon={CheckCircle} color="green" />
        <StatCard
          title="Avg Viral Score"
          value={`${avgScore}/100`}
          icon={TrendingUp}
          color="orange"
        />
        <StatCard
          title="Avg Duration"
          value={`${avgDuration}s`}
          icon={Clock}
          color="blue"
        />
      </div>

      {/* Charts row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        {/* Viral score distribution */}
        <div className="bg-gray-900 border border-gray-800 rounded-2xl p-6">
          <h2 className="text-white font-bold mb-1">Viral Score Distribution</h2>
          <p className="text-gray-500 text-sm mb-5">How your clips score on the AI viral scale</p>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={scoreData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#1f2937" />
              <XAxis dataKey="range" tick={{ fill: "#6b7280", fontSize: 12 }} />
              <YAxis tick={{ fill: "#6b7280", fontSize: 12 }} allowDecimals={false} />
              <Tooltip
                contentStyle={{
                  background: "#111827",
                  border: "1px solid #374151",
                  borderRadius: "12px",
                  color: "#f9fafb",
                }}
              />
              <Bar dataKey="count" fill="#7c3aed" radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Status pie chart */}
        <div className="bg-gray-900 border border-gray-800 rounded-2xl p-6">
          <h2 className="text-white font-bold mb-1">Clip Status Breakdown</h2>
          <p className="text-gray-500 text-sm mb-5">Distribution by current status</p>
          {statusData.length > 0 ? (
            <ResponsiveContainer width="100%" height={220}>
              <PieChart>
                <Pie
                  data={statusData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={90}
                  paddingAngle={4}
                  dataKey="value"
                >
                  {statusData.map((entry, index) => (
                    <Cell key={entry.name} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{
                    background: "#111827",
                    border: "1px solid #374151",
                    borderRadius: "12px",
                    color: "#f9fafb",
                  }}
                />
                <Legend
                  formatter={(value) => (
                    <span style={{ color: "#9ca3af", fontSize: "12px" }}>{value}</span>
                  )}
                />
              </PieChart>
            </ResponsiveContainer>
          ) : (
            <div className="flex items-center justify-center h-[220px] text-gray-600">
              No clips yet
            </div>
          )}
        </div>
      </div>

      {/* Platform chart */}
      <div className="bg-gray-900 border border-gray-800 rounded-2xl p-6">
        <div className="flex items-center gap-2 mb-1">
          <BarChart3 className="w-5 h-5 text-violet-400" />
          <h2 className="text-white font-bold">Platform Distribution</h2>
        </div>
        <p className="text-gray-500 text-sm mb-5">
          How many clips are targeted at each platform
        </p>
        <ResponsiveContainer width="100%" height={200}>
          <BarChart data={platformData} layout="vertical">
            <CartesianGrid strokeDasharray="3 3" stroke="#1f2937" horizontal={false} />
            <XAxis type="number" tick={{ fill: "#6b7280", fontSize: 12 }} allowDecimals={false} />
            <YAxis
              dataKey="name"
              type="category"
              tick={{ fill: "#9ca3af", fontSize: 13 }}
              width={80}
            />
            <Tooltip
              contentStyle={{
                background: "#111827",
                border: "1px solid #374151",
                borderRadius: "12px",
                color: "#f9fafb",
              }}
            />
            <Bar dataKey="count" fill="#6366f1" radius={[0, 6, 6, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}
