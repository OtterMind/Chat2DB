"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import { Plus, Trash2, RefreshCw, Users, ListVideo, ArrowRight, ExternalLink } from "lucide-react";
import { formatNumber, timeAgo } from "@/lib/utils";
import AddChannelModal from "@/components/AddChannelModal";

interface Channel {
  id: number;
  channelId: string;
  channelName: string;
  channelUrl: string;
  thumbnailUrl: string | null;
  description: string | null;
  subscriberCount: number | null;
  videoCount: number;
  clipCount: number;
  lastSyncedAt: string | null;
  createdAt: string;
}

export default function ChannelsPage() {
  const [channels, setChannels] = useState<Channel[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAdd, setShowAdd] = useState(false);
  const [syncing, setSyncing] = useState<number | null>(null);
  const [deleting, setDeleting] = useState<number | null>(null);

  const loadChannels = async () => {
    const res = await fetch("/api/channels");
    const data = await res.json();
    setChannels(data.channels || []);
    setLoading(false);
  };

  useEffect(() => {
    loadChannels();
  }, []);

  const handleDelete = async (id: number) => {
    if (!confirm("Remove this channel and all its videos/clips?")) return;
    setDeleting(id);
    await fetch(`/api/channels/${id}`, { method: "DELETE" });
    setChannels((prev) => prev.filter((c) => c.id !== id));
    setDeleting(null);
  };

  const handleSync = async (id: number) => {
    setSyncing(id);
    await fetch(`/api/channels/${id}/videos`, { method: "POST" });
    await loadChannels();
    setSyncing(null);
  };

  return (
    <div className="p-8 max-w-7xl mx-auto">
      <div className="flex items-start justify-between mb-8">
        <div>
          <h1 className="text-3xl font-bold text-white">Channels</h1>
          <p className="text-gray-400 mt-1">
            Connect and manage your YouTube channels
          </p>
        </div>
        <button
          onClick={() => setShowAdd(true)}
          className="flex items-center gap-2 bg-violet-600 hover:bg-violet-500 text-white text-sm font-semibold px-4 py-2 rounded-xl transition-colors"
        >
          <Plus className="w-4 h-4" />
          Add Channel
        </button>
      </div>

      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {[1, 2, 3].map((i) => (
            <div key={i} className="bg-gray-900 border border-gray-800 rounded-2xl p-6 animate-pulse">
              <div className="flex items-center gap-4 mb-4">
                <div className="w-14 h-14 bg-gray-800 rounded-xl" />
                <div className="flex-1">
                  <div className="h-4 bg-gray-800 rounded mb-2 w-3/4" />
                  <div className="h-3 bg-gray-800 rounded w-1/2" />
                </div>
              </div>
              <div className="h-3 bg-gray-800 rounded mb-2" />
              <div className="h-3 bg-gray-800 rounded w-3/4" />
            </div>
          ))}
        </div>
      ) : channels.length === 0 ? (
        <div className="text-center py-24">
          <ListVideo className="w-14 h-14 text-gray-700 mx-auto mb-4" />
          <h2 className="text-xl font-semibold text-gray-400 mb-2">No channels yet</h2>
          <p className="text-gray-600 mb-6">
            Connect a YouTube channel to start generating AI-powered clips
          </p>
          <button
            onClick={() => setShowAdd(true)}
            className="bg-violet-600 hover:bg-violet-500 text-white font-semibold px-6 py-3 rounded-xl transition-colors inline-flex items-center gap-2"
          >
            <Plus className="w-4 h-4" />
            Connect First Channel
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {channels.map((ch) => (
            <div
              key={ch.id}
              className="bg-gray-900 border border-gray-800 hover:border-gray-700 rounded-2xl p-6 transition-colors"
            >
              {/* Channel header */}
              <div className="flex items-start gap-4 mb-4">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src={ch.thumbnailUrl || "https://placehold.co/56x56/374151/6b7280?text=YT"}
                  alt={ch.channelName}
                  className="w-14 h-14 rounded-xl object-cover flex-shrink-0"
                />
                <div className="flex-1 min-w-0">
                  <h3 className="text-white font-bold text-base truncate">{ch.channelName}</h3>
                  {ch.subscriberCount ? (
                    <div className="flex items-center gap-1 text-gray-500 text-xs mt-1">
                      <Users className="w-3 h-3" />
                      {formatNumber(ch.subscriberCount)} subscribers
                    </div>
                  ) : null}
                  {ch.lastSyncedAt && (
                    <p className="text-gray-600 text-xs mt-0.5">
                      Synced {timeAgo(ch.lastSyncedAt)}
                    </p>
                  )}
                </div>
              </div>

              {/* Description */}
              {ch.description && (
                <p className="text-gray-500 text-xs leading-relaxed mb-4 line-clamp-2">
                  {ch.description}
                </p>
              )}

              {/* Stats */}
              <div className="grid grid-cols-2 gap-3 mb-4">
                <div className="bg-gray-800/60 rounded-xl p-3 text-center">
                  <p className="text-white font-bold text-lg">{ch.videoCount}</p>
                  <p className="text-gray-500 text-xs">Videos</p>
                </div>
                <div className="bg-violet-900/30 border border-violet-800/30 rounded-xl p-3 text-center">
                  <p className="text-violet-300 font-bold text-lg">{ch.clipCount}</p>
                  <p className="text-gray-500 text-xs">AI Clips</p>
                </div>
              </div>

              {/* Actions */}
              <div className="flex items-center gap-2">
                <Link
                  href={`/channels/${ch.id}`}
                  className="flex-1 flex items-center justify-center gap-1.5 bg-violet-600/20 hover:bg-violet-600/30 text-violet-300 text-sm font-medium px-4 py-2 rounded-xl transition-colors border border-violet-700/30"
                >
                  View Videos
                  <ArrowRight className="w-3.5 h-3.5" />
                </Link>
                <button
                  onClick={() => handleSync(ch.id)}
                  disabled={syncing === ch.id}
                  title="Sync latest videos"
                  className="p-2 bg-gray-800 hover:bg-gray-700 text-gray-400 hover:text-gray-200 rounded-xl transition-colors disabled:opacity-50"
                >
                  <RefreshCw className={`w-4 h-4 ${syncing === ch.id ? "animate-spin" : ""}`} />
                </button>
                <a
                  href={ch.channelUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  title="Open on YouTube"
                  className="p-2 bg-gray-800 hover:bg-gray-700 text-gray-400 hover:text-gray-200 rounded-xl transition-colors"
                >
                  <ExternalLink className="w-4 h-4" />
                </a>
                <button
                  onClick={() => handleDelete(ch.id)}
                  disabled={deleting === ch.id}
                  title="Remove channel"
                  className="p-2 bg-red-900/20 hover:bg-red-900/40 text-red-500 hover:text-red-400 rounded-xl transition-colors disabled:opacity-50"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {showAdd && (
        <AddChannelModal
          onClose={() => setShowAdd(false)}
          onSuccess={() => loadChannels()}
        />
      )}
    </div>
  );
}
