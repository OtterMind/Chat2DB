"use client";
import { useEffect, useState, use } from "react";
import Link from "next/link";
import {
  ArrowLeft,
  RefreshCw,
  Scissors,
  Play,
  Eye,
  ThumbsUp,
  MessageCircle,
  Clock,
  Loader2,
  CheckCircle2,
  AlertCircle,
  ExternalLink,
} from "lucide-react";
import { formatDuration, formatNumber, timeAgo } from "@/lib/utils";
import { cn } from "@/lib/utils";

interface Video {
  id: number;
  videoId: string;
  title: string;
  thumbnailUrl: string | null;
  duration: number | null;
  viewCount: number | null;
  likeCount: number | null;
  commentCount: number | null;
  publishedAt: string | null;
  status: string | null;
  clipsGenerated: boolean;
  transcriptFetched: boolean;
}

interface Channel {
  id: number;
  channelName: string;
  channelUrl: string;
  thumbnailUrl: string | null;
  subscriberCount: number | null;
}

export default function ChannelPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = use(params);
  const [channel, setChannel] = useState<Channel | null>(null);
  const [videos, setVideos] = useState<Video[]>([]);
  const [loading, setLoading] = useState(true);
  const [syncing, setSyncing] = useState(false);
  const [processing, setProcessing] = useState<number | null>(null);
  const [processMsg, setProcessMsg] = useState<Record<number, string>>({});

  const loadData = async () => {
    const [chRes, vidRes] = await Promise.all([
      fetch(`/api/channels/${id}`),
      fetch(`/api/channels/${id}/videos`),
    ]);
    const chData = await chRes.json();
    const vidData = await vidRes.json();
    setChannel(chData.channel);
    setVideos(vidData.videos || []);
    setLoading(false);
  };

  useEffect(() => {
    loadData();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  const handleSync = async () => {
    setSyncing(true);
    await fetch(`/api/channels/${id}/videos`, { method: "POST" });
    await loadData();
    setSyncing(false);
  };

  const handleProcess = async (videoId: number) => {
    setProcessing(videoId);
    setProcessMsg((p) => ({ ...p, [videoId]: "Fetching transcript..." }));
    try {
      setProcessMsg((p) => ({ ...p, [videoId]: "AI analyzing viral moments..." }));
      const res = await fetch(`/api/videos/${videoId}/process`, { method: "POST" });
      const data = await res.json();
      if (res.ok) {
        setProcessMsg((p) => ({
          ...p,
          [videoId]: `✅ ${data.clips?.length || 0} clips generated!`,
        }));
        await loadData();
        setTimeout(() => {
          setProcessMsg((p) => {
            const n = { ...p };
            delete n[videoId];
            return n;
          });
        }, 3000);
      } else {
        setProcessMsg((p) => ({ ...p, [videoId]: `❌ ${data.error}` }));
      }
    } finally {
      setProcessing(null);
    }
  };

  const statusConfig: Record<string, { label: string; color: string; icon: React.ReactNode }> = {
    pending: {
      label: "Pending",
      color: "text-gray-400 bg-gray-800 border-gray-700",
      icon: <Clock className="w-3 h-3" />,
    },
    processing: {
      label: "Processing",
      color: "text-yellow-400 bg-yellow-900/20 border-yellow-700/30",
      icon: <Loader2 className="w-3 h-3 animate-spin" />,
    },
    done: {
      label: "Done",
      color: "text-green-400 bg-green-900/20 border-green-700/30",
      icon: <CheckCircle2 className="w-3 h-3" />,
    },
    error: {
      label: "Error",
      color: "text-red-400 bg-red-900/20 border-red-700/30",
      icon: <AlertCircle className="w-3 h-3" />,
    },
  };

  if (loading) {
    return (
      <div className="p-8 max-w-7xl mx-auto">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-gray-800 rounded w-1/3" />
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <div key={i} className="bg-gray-900 border border-gray-800 rounded-2xl h-64" />
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-8 max-w-7xl mx-auto">
      {/* Header */}
      <div className="mb-6">
        <Link
          href="/channels"
          className="inline-flex items-center gap-1.5 text-gray-500 hover:text-gray-300 text-sm mb-4 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Channels
        </Link>
        {channel && (
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src={channel.thumbnailUrl || "https://placehold.co/56x56/374151/6b7280?text=YT"}
                alt={channel.channelName}
                className="w-12 h-12 rounded-xl"
              />
              <div>
                <h1 className="text-2xl font-bold text-white">{channel.channelName}</h1>
                <div className="flex items-center gap-3 text-gray-500 text-sm">
                  {channel.subscriberCount && (
                    <span>{formatNumber(channel.subscriberCount)} subscribers</span>
                  )}
                  <span>•</span>
                  <span>{videos.length} videos loaded</span>
                  <a
                    href={channel.channelUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1 text-violet-400 hover:text-violet-300 transition-colors"
                  >
                    Open on YouTube
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
              </div>
            </div>
            <button
              onClick={handleSync}
              disabled={syncing}
              className="flex items-center gap-2 bg-gray-800 hover:bg-gray-700 text-gray-300 text-sm px-4 py-2 rounded-xl transition-colors disabled:opacity-50"
            >
              <RefreshCw className={`w-4 h-4 ${syncing ? "animate-spin" : ""}`} />
              Sync Videos
            </button>
          </div>
        )}
      </div>

      {/* Videos grid */}
      {videos.length === 0 ? (
        <div className="text-center py-20">
          <Play className="w-12 h-12 text-gray-700 mx-auto mb-4" />
          <h2 className="text-lg font-semibold text-gray-400 mb-2">No videos yet</h2>
          <p className="text-gray-600 mb-4">Sync videos from this channel to get started</p>
          <button
            onClick={handleSync}
            disabled={syncing}
            className="bg-violet-600 hover:bg-violet-500 text-white font-semibold px-6 py-3 rounded-xl transition-colors inline-flex items-center gap-2 disabled:opacity-50"
          >
            <RefreshCw className={`w-4 h-4 ${syncing ? "animate-spin" : ""}`} />
            Sync Now
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {videos.map((v) => {
            const status = v.status || "pending";
            const cfg = statusConfig[status] || statusConfig.pending;
            const msg = processMsg[v.id];
            return (
              <div
                key={v.id}
                className="bg-gray-900 border border-gray-800 hover:border-gray-700 rounded-2xl overflow-hidden transition-colors"
              >
                {/* Thumbnail */}
                <div className="relative">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img
                    src={v.thumbnailUrl || "https://placehold.co/480x270/1f2937/374151?text=Video"}
                    alt={v.title}
                    className="w-full aspect-video object-cover"
                  />
                  {v.duration && (
                    <div className="absolute bottom-2 right-2 bg-black/80 text-white text-xs px-2 py-0.5 rounded font-mono">
                      {formatDuration(v.duration)}
                    </div>
                  )}
                  <div className={cn("absolute top-2 right-2 flex items-center gap-1 px-2 py-1 rounded-lg text-xs font-medium border", cfg.color)}>
                    {cfg.icon}
                    {cfg.label}
                  </div>
                </div>

                {/* Content */}
                <div className="p-4">
                  <h3 className="text-white font-semibold text-sm leading-snug mb-2 line-clamp-2">
                    {v.title}
                  </h3>
                  <div className="flex items-center gap-3 text-gray-500 text-xs mb-3">
                    {v.viewCount !== null && (
                      <span className="flex items-center gap-1">
                        <Eye className="w-3 h-3" />
                        {formatNumber(v.viewCount)}
                      </span>
                    )}
                    {v.likeCount !== null && (
                      <span className="flex items-center gap-1">
                        <ThumbsUp className="w-3 h-3" />
                        {formatNumber(v.likeCount)}
                      </span>
                    )}
                    {v.commentCount !== null && (
                      <span className="flex items-center gap-1">
                        <MessageCircle className="w-3 h-3" />
                        {formatNumber(v.commentCount)}
                      </span>
                    )}
                    {v.publishedAt && (
                      <span className="ml-auto">{timeAgo(v.publishedAt)}</span>
                    )}
                  </div>

                  {/* Processing message */}
                  {msg && (
                    <div className="bg-gray-800/60 rounded-xl px-3 py-2 text-xs text-gray-300 mb-3">
                      {msg}
                    </div>
                  )}

                  {/* Actions */}
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => handleProcess(v.id)}
                      disabled={processing === v.id || status === "processing"}
                      className="flex-1 flex items-center justify-center gap-1.5 bg-violet-600/20 hover:bg-violet-600/30 text-violet-300 text-xs font-medium px-3 py-2 rounded-xl transition-colors border border-violet-700/30 disabled:opacity-50"
                    >
                      {processing === v.id ? (
                        <>
                          <Loader2 className="w-3 h-3 animate-spin" />
                          Processing...
                        </>
                      ) : (
                        <>
                          <Scissors className="w-3 h-3" />
                          {status === "done" ? "Re-generate Clips" : "Generate Clips"}
                        </>
                      )}
                    </button>
                    {status === "done" && (
                      <Link
                        href={`/clips?videoId=${v.id}`}
                        className="flex items-center gap-1.5 bg-green-900/20 hover:bg-green-900/30 text-green-400 text-xs font-medium px-3 py-2 rounded-xl transition-colors border border-green-700/30"
                      >
                        View Clips
                      </Link>
                    )}
                    <a
                      href={`https://www.youtube.com/watch?v=${v.videoId}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="p-2 bg-gray-800 hover:bg-gray-700 text-gray-400 rounded-xl transition-colors"
                    >
                      <ExternalLink className="w-3.5 h-3.5" />
                    </a>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
