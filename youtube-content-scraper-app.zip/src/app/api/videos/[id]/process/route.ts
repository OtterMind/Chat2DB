import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { videos, transcripts, clips } from "@/db/schema";
import { eq } from "drizzle-orm";
import { fetchTranscript } from "@/lib/youtube";
import {
  generateClipSuggestions,
  generateMockClips,
} from "@/lib/ai-clipper";

// POST /api/videos/:id/process - fetch transcript + generate clips
export async function POST(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const videoId = parseInt(id);

    const [video] = await db
      .select()
      .from(videos)
      .where(eq(videos.id, videoId))
      .limit(1);

    if (!video) {
      return NextResponse.json({ error: "Video not found" }, { status: 404 });
    }

    // Update status to processing
    await db
      .update(videos)
      .set({ status: "processing" })
      .where(eq(videos.id, videoId));

    // ── Fetch transcript ──────────────────────────────────────────────────
    let segments = null;
    let existingTranscript = await db
      .select()
      .from(transcripts)
      .where(eq(transcripts.videoId, videoId))
      .limit(1);

    if (existingTranscript.length && existingTranscript[0].segments) {
      segments = existingTranscript[0].segments as {
        text: string;
        start: number;
        duration: number;
      }[];
    } else {
      segments = await fetchTranscript(video.videoId);
      if (segments) {
        const fullText = segments.map((s) => s.text).join(" ");
        if (existingTranscript.length) {
          await db
            .update(transcripts)
            .set({ segments, fullText, language: "en" })
            .where(eq(transcripts.videoId, videoId));
        } else {
          await db.insert(transcripts).values({
            videoId,
            fullText,
            segments,
            language: "en",
          });
        }
        await db
          .update(videos)
          .set({ transcriptFetched: true })
          .where(eq(videos.id, videoId));
      }
    }

    // ── Generate clips ────────────────────────────────────────────────────
    const videoDuration = video.duration || 600;

    // Delete existing clips for this video
    await db.delete(clips).where(eq(clips.videoId, videoId));

    let clipSuggestions;
    if (process.env.OPENAI_API_KEY && segments) {
      try {
        clipSuggestions = await generateClipSuggestions(
          video.title,
          segments,
          videoDuration,
          5
        );
      } catch (e) {
        console.error("AI clip gen failed, falling back to mock:", e);
        clipSuggestions = generateMockClips(
          video.title,
          segments || [],
          videoDuration,
          5
        );
      }
    } else {
      clipSuggestions = generateMockClips(
        video.title,
        segments || [],
        videoDuration,
        5
      );
    }

    // Insert clips
    const insertedClips = [];
    for (const c of clipSuggestions) {
      const [inserted] = await db
        .insert(clips)
        .values({
          videoId,
          channelId: video.channelId,
          title: c.title,
          description: c.description,
          startTime: c.startTime,
          endTime: c.endTime,
          duration: c.duration,
          viralScore: c.viralScore,
          reason: c.reason,
          transcript: c.transcript,
          format: c.format,
          status: "ready",
          platforms: { tiktok: true, instagram: true, youtube: true, facebook: false },
        })
        .returning();
      insertedClips.push(inserted);
    }

    // Update video status
    await db
      .update(videos)
      .set({ status: "done", clipsGenerated: true })
      .where(eq(videos.id, videoId));

    return NextResponse.json({
      success: true,
      clips: insertedClips,
      transcriptAvailable: !!segments,
    });
  } catch (err) {
    console.error(err);
    // Update status to error
    const { id } = await params;
    await db
      .update(videos)
      .set({ status: "error" })
      .where(eq(videos.id, parseInt(id)));
    return NextResponse.json({ error: "Processing failed" }, { status: 500 });
  }
}
