import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { clips, videos, channels } from "@/db/schema";
import { desc, eq } from "drizzle-orm";

// GET /api/clips - get all clips (optionally filtered by channelId or videoId)
export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const channelId = searchParams.get("channelId");
    const videoId = searchParams.get("videoId");

    let query = db
      .select({
        clip: clips,
        video: {
          videoId: videos.videoId,
          title: videos.title,
          thumbnailUrl: videos.thumbnailUrl,
          duration: videos.duration,
        },
        channel: {
          channelName: channels.channelName,
          channelId: channels.channelId,
        },
      })
      .from(clips)
      .leftJoin(videos, eq(clips.videoId, videos.id))
      .leftJoin(channels, eq(clips.channelId, channels.id))
      .orderBy(desc(clips.createdAt));

    if (channelId) {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      (query as any).where(eq(clips.channelId, parseInt(channelId)));
    }
    if (videoId) {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      (query as any).where(eq(clips.videoId, parseInt(videoId)));
    }

    const rows = await query;
    return NextResponse.json({ clips: rows });
  } catch (err) {
    console.error(err);
    return NextResponse.json({ error: "Failed to fetch clips" }, { status: 500 });
  }
}
