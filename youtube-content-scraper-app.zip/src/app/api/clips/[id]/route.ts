import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { clips } from "@/db/schema";
import { eq } from "drizzle-orm";

// PATCH /api/clips/:id - update clip status/platforms
export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const clipId = parseInt(id);
    const body = await req.json();

    const updateData: Partial<typeof clips.$inferInsert> = {};
    if (body.status) updateData.status = body.status;
    if (body.platforms) updateData.platforms = body.platforms;
    if (body.title) updateData.title = body.title;
    if (body.description) updateData.description = body.description;
    if (body.status === "posted") updateData.postedAt = new Date();

    const [updated] = await db
      .update(clips)
      .set(updateData)
      .where(eq(clips.id, clipId))
      .returning();

    return NextResponse.json({ clip: updated });
  } catch (err) {
    console.error(err);
    return NextResponse.json({ error: "Failed to update clip" }, { status: 500 });
  }
}

// DELETE /api/clips/:id
export async function DELETE(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const clipId = parseInt(id);
    await db.delete(clips).where(eq(clips.id, clipId));
    return NextResponse.json({ success: true });
  } catch (err) {
    console.error(err);
    return NextResponse.json({ error: "Failed to delete clip" }, { status: 500 });
  }
}
