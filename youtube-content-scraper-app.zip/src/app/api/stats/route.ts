import { NextResponse } from "next/server";
import { db } from "@/db";
import { channels, videos, clips } from "@/db/schema";
import { count, eq, desc } from "drizzle-orm";

export async function GET() {
  try {
    const [channelCount] = await db.select({ count: count() }).from(channels);
    const [videoCount] = await db.select({ count: count() }).from(videos);
    const [clipCount] = await db.select({ count: count() }).from(clips);
    const [postedCount] = await db
      .select({ count: count() })
      .from(clips)
      .where(eq(clips.status, "posted"));
    const [readyCount] = await db
      .select({ count: count() })
      .from(clips)
      .where(eq(clips.status, "ready"));

    // Recent clips
    const recentClips = await db
      .select()
      .from(clips)
      .orderBy(desc(clips.createdAt))
      .limit(5);

    return NextResponse.json({
      channels: channelCount.count,
      videos: videoCount.count,
      clips: clipCount.count,
      postedClips: postedCount.count,
      readyClips: readyCount.count,
      recentClips,
    });
  } catch (err) {
    console.error(err);
    return NextResponse.json({ error: "Failed to fetch stats" }, { status: 500 });
  }
}
