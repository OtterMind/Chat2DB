import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { channels, videos } from "@/db/schema";
import { eq, desc } from "drizzle-orm";
import { fetchChannelVideos } from "@/lib/youtube";

// GET /api/channels/:id/videos
export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const channelId = parseInt(id);

    const rows = await db
      .select()
      .from(videos)
      .where(eq(videos.channelId, channelId))
      .orderBy(desc(videos.publishedAt));

    return NextResponse.json({ videos: rows });
  } catch (err) {
    console.error(err);
    return NextResponse.json({ error: "Failed to fetch videos" }, { status: 500 });
  }
}

// POST /api/channels/:id/videos - sync latest videos
export async function POST(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const channelId = parseInt(id);

    const [channel] = await db
      .select()
      .from(channels)
      .where(eq(channels.id, channelId))
      .limit(1);

    if (!channel) {
      return NextResponse.json({ error: "Channel not found" }, { status: 404 });
    }

    if (!process.env.YOUTUBE_API_KEY) {
      // Demo mode: return existing videos
      const rows = await db
        .select()
        .from(videos)
        .where(eq(videos.channelId, channelId))
        .orderBy(desc(videos.publishedAt));
      return NextResponse.json({ videos: rows, synced: 0, demo: true });
    }

    const ytVideos = await fetchChannelVideos(channel.channelId, 25);
    let synced = 0;

    for (const v of ytVideos) {
      const exists = await db
        .select()
        .from(videos)
        .where(eq(videos.videoId, v.videoId))
        .limit(1);
      if (!exists.length) {
        await db.insert(videos).values({
          channelId,
          videoId: v.videoId,
          title: v.title,
          description: v.description,
          thumbnailUrl: v.thumbnailUrl,
          duration: v.duration,
          viewCount: v.viewCount,
          likeCount: v.likeCount,
          commentCount: v.commentCount,
          publishedAt: v.publishedAt,
        });
        synced++;
      }
    }

    await db
      .update(channels)
      .set({ lastSyncedAt: new Date() })
      .where(eq(channels.id, channelId));

    const rows = await db
      .select()
      .from(videos)
      .where(eq(videos.channelId, channelId))
      .orderBy(desc(videos.publishedAt));

    return NextResponse.json({ videos: rows, synced });
  } catch (err) {
    console.error(err);
    return NextResponse.json({ error: "Failed to sync videos" }, { status: 500 });
  }
}
