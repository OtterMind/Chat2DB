import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { channels, videos, clips } from "@/db/schema";
import { eq } from "drizzle-orm";

// DELETE /api/channels/:id
export async function DELETE(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const channelId = parseInt(id);
    if (isNaN(channelId)) {
      return NextResponse.json({ error: "Invalid ID" }, { status: 400 });
    }
    await db.delete(clips).where(eq(clips.channelId, channelId));
    await db.delete(videos).where(eq(videos.channelId, channelId));
    await db.delete(channels).where(eq(channels.id, channelId));
    return NextResponse.json({ success: true });
  } catch (err) {
    console.error(err);
    return NextResponse.json({ error: "Failed to delete channel" }, { status: 500 });
  }
}

// GET /api/channels/:id
export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const channelId = parseInt(id);
    const [channel] = await db
      .select()
      .from(channels)
      .where(eq(channels.id, channelId))
      .limit(1);
    if (!channel) {
      return NextResponse.json({ error: "Channel not found" }, { status: 404 });
    }
    return NextResponse.json({ channel });
  } catch (err) {
    console.error(err);
    return NextResponse.json({ error: "Failed to fetch channel" }, { status: 500 });
  }
}
