import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { channels, videos, clips } from "@/db/schema";
import { desc, eq, count } from "drizzle-orm";
import {
  resolveChannelFromVideoUrl,
  fetchChannelInfo,
  fetchChannelByHandle,
  fetchChannelVideos,
} from "@/lib/youtube";
import { extractChannelId } from "@/lib/utils";

// GET /api/channels - list all channels with stats
export async function GET() {
  try {
    const rows = await db
      .select()
      .from(channels)
      .orderBy(desc(channels.createdAt));

    // Enrich with video/clip counts
    const enriched = await Promise.all(
      rows.map(async (ch) => {
        const [vc] = await db
          .select({ count: count() })
          .from(videos)
          .where(eq(videos.channelId, ch.id));
        const [cc] = await db
          .select({ count: count() })
          .from(clips)
          .where(eq(clips.channelId, ch.id));
        return { ...ch, videoCount: vc.count, clipCount: cc.count };
      })
    );

    return NextResponse.json({ channels: enriched });
  } catch (err) {
    console.error(err);
    return NextResponse.json({ error: "Failed to fetch channels" }, { status: 500 });
  }
}

// POST /api/channels - add a new channel
export async function POST(req: NextRequest) {
  try {
    const { url } = await req.json();
    if (!url) {
      return NextResponse.json({ error: "URL is required" }, { status: 400 });
    }

    const apiKey = process.env.YOUTUBE_API_KEY;

    // ── Demo mode (no API key) ──────────────────────────────────────────────
    if (!apiKey) {
      const demoChannel = {
        channelId: `demo_${Date.now()}`,
        channelName: "Demo Channel (Add YouTube API Key)",
        channelUrl: url,
        thumbnailUrl: "https://placehold.co/100x100/6366f1/white?text=YT",
        description: "This is a demo channel. Add your YOUTUBE_API_KEY to connect real channels.",
        subscriberCount: 125000,
        videoCount: 48,
      };
      const existing = await db
        .select()
        .from(channels)
        .where(eq(channels.channelId, demoChannel.channelId))
        .limit(1);
      if (existing.length) {
        return NextResponse.json({ channel: existing[0] });
      }
      const [inserted] = await db.insert(channels).values(demoChannel).returning();
      return NextResponse.json({ channel: inserted });
    }

    // ── Real mode (with API key) ────────────────────────────────────────────
    let channelInfo = null;

    // Try to detect if it's a video URL
    if (url.includes("watch?v=") || url.includes("youtu.be/") || url.includes("/shorts/")) {
      const resolved = await resolveChannelFromVideoUrl(url);
      if (resolved) {
        channelInfo = await fetchChannelInfo(resolved.channelId);
      }
    }

    // Try channel URL patterns
    if (!channelInfo) {
      const directId = extractChannelId(url);
      if (directId) {
        if (url.includes("/channel/")) {
          channelInfo = await fetchChannelInfo(directId);
        } else {
          channelInfo = await fetchChannelByHandle(directId);
        }
      }
    }

    // Fallback: try as channel ID directly
    if (!channelInfo && url.startsWith("UC")) {
      channelInfo = await fetchChannelInfo(url.trim());
    }

    if (!channelInfo) {
      return NextResponse.json(
        { error: "Could not find YouTube channel from this URL. Try a video URL or channel URL." },
        { status: 404 }
      );
    }

    // Check if already exists
    const existing = await db
      .select()
      .from(channels)
      .where(eq(channels.channelId, channelInfo.channelId))
      .limit(1);
    if (existing.length) {
      return NextResponse.json({ channel: existing[0], alreadyExists: true });
    }

    // Insert channel
    const [inserted] = await db
      .insert(channels)
      .values({
        channelId: channelInfo.channelId,
        channelName: channelInfo.channelName,
        channelUrl: channelInfo.channelUrl,
        thumbnailUrl: channelInfo.thumbnailUrl,
        description: channelInfo.description,
        subscriberCount: channelInfo.subscriberCount,
        videoCount: channelInfo.videoCount,
        lastSyncedAt: new Date(),
      })
      .returning();

    // Fetch and store videos in background
    fetchChannelVideos(channelInfo.channelId, 15)
      .then(async (ytVideos) => {
        for (const v of ytVideos) {
          const exists = await db
            .select()
            .from(videos)
            .where(eq(videos.videoId, v.videoId))
            .limit(1);
          if (!exists.length) {
            await db.insert(videos).values({
              channelId: inserted.id,
              videoId: v.videoId,
              title: v.title,
              description: v.description,
              thumbnailUrl: v.thumbnailUrl,
              duration: v.duration,
              viewCount: v.viewCount,
              likeCount: v.likeCount,
              commentCount: v.commentCount,
              publishedAt: v.publishedAt,
            });
          }
        }
      })
      .catch(console.error);

    return NextResponse.json({ channel: inserted });
  } catch (err) {
    console.error(err);
    return NextResponse.json({ error: "Failed to add channel" }, { status: 500 });
  }
}
