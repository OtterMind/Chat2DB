import { NextResponse } from "next/server";
import { db } from "@/db";
import { channels, videos, clips } from "@/db/schema";
import { eq } from "drizzle-orm";

const DEMO_CHANNEL_ID = "demo_seed_001";

export async function POST() {
  try {
    // Check if already seeded
    const existing = await db
      .select()
      .from(channels)
      .where(eq(channels.channelId, DEMO_CHANNEL_ID))
      .limit(1);

    if (existing.length) {
      return NextResponse.json({ message: "Already seeded", channelId: existing[0].id });
    }

    // Insert demo channel
    const [channel] = await db
      .insert(channels)
      .values({
        channelId: DEMO_CHANNEL_ID,
        channelName: "TechExplained Pro",
        channelUrl: "https://www.youtube.com/@techexplainedpro",
        thumbnailUrl: "https://placehold.co/100x100/6366f1/white?text=TE",
        description: "Explaining complex tech topics in simple terms. 500K+ subscribers.",
        subscriberCount: 524000,
        videoCount: 127,
        lastSyncedAt: new Date(),
      })
      .returning();

    const demoVideos = [
      {
        videoId: "demo_vid_001",
        title: "Why AI Will Change Everything in 2025 - Full Analysis",
        thumbnailUrl: "https://placehold.co/480x270/1e1b4b/6366f1?text=AI+Revolution",
        duration: 1820,
        viewCount: 284500,
        likeCount: 12300,
        commentCount: 1850,
        publishedAt: new Date("2025-01-15"),
      },
      {
        videoId: "demo_vid_002",
        title: "I Tested 10 AI Tools So You Don't Have To",
        thumbnailUrl: "https://placehold.co/480x270/1e1b4b/8b5cf6?text=AI+Tools",
        duration: 2340,
        viewCount: 198700,
        likeCount: 9400,
        commentCount: 2100,
        publishedAt: new Date("2025-01-08"),
      },
      {
        videoId: "demo_vid_003",
        title: "The Truth About Passive Income Online in 2025",
        thumbnailUrl: "https://placehold.co/480x270/1e1b4b/10b981?text=Passive+Income",
        duration: 1560,
        viewCount: 412000,
        likeCount: 18700,
        commentCount: 3200,
        publishedAt: new Date("2024-12-28"),
      },
      {
        videoId: "demo_vid_004",
        title: "How I Built a $10K/Month SaaS in 90 Days",
        thumbnailUrl: "https://placehold.co/480x270/1e1b4b/f59e0b?text=SaaS+Journey",
        duration: 3240,
        viewCount: 356000,
        likeCount: 15200,
        commentCount: 2800,
        publishedAt: new Date("2024-12-15"),
      },
    ];

    const insertedVideos = [];
    for (const v of demoVideos) {
      const [vid] = await db
        .insert(videos)
        .values({
          channelId: channel.id,
          ...v,
          status: "done",
          transcriptFetched: true,
          clipsGenerated: true,
        })
        .returning();
      insertedVideos.push(vid);
    }

    // Generate demo clips for first video
    const demoClips = [
      {
        videoId: insertedVideos[0].id,
        channelId: channel.id,
        title: "AI will make 40% of jobs obsolete by 2030",
        description: "🤯 This is happening faster than anyone expected #AI #future #technology",
        startTime: 120,
        endTime: 165,
        duration: 45,
        viralScore: 92,
        reason: "Shocking statistic with emotional impact. Perfect hook for Shorts.",
        transcript: "What most people don't realize is that AI isn't just automating repetitive tasks anymore...",
        format: "vertical",
        status: "ready",
        platforms: { tiktok: true, instagram: true, youtube: true, facebook: false },
      },
      {
        videoId: insertedVideos[0].id,
        channelId: channel.id,
        title: "The secret tool every creator needs right now",
        description: "💡 I can't believe this is free #creator #tools #productivity",
        startTime: 480,
        endTime: 535,
        duration: 55,
        viralScore: 78,
        reason: "High curiosity gap — 'secret tool' drives replays and saves.",
        transcript: "There's one tool that completely changed how I create content...",
        format: "vertical",
        status: "posted",
        platforms: { tiktok: true, instagram: true, youtube: true, facebook: false },
      },
      {
        videoId: insertedVideos[0].id,
        channelId: channel.id,
        title: "Nobody is talking about this AI breakthrough",
        description: "🔬 This changes the game completely #AI #breakthrough #tech",
        startTime: 860,
        endTime: 915,
        duration: 55,
        viralScore: 85,
        reason: "FOMO-driven hook, educational content with surprising reveal.",
        transcript: "In the last 6 months, there has been a breakthrough that almost nobody has covered...",
        format: "vertical",
        status: "ready",
        platforms: { tiktok: true, instagram: false, youtube: true, facebook: false },
      },
      {
        videoId: insertedVideos[1].id,
        channelId: channel.id,
        title: "This AI tool saved me 20 hours this week",
        description: "⏰ Time is money and this just gave me mine back #AI #productivity",
        startTime: 200,
        endTime: 248,
        duration: 48,
        viralScore: 71,
        reason: "Relatable productivity win, strong personal testimonial.",
        transcript: "I spent an entire week testing these tools so you don't have to...",
        format: "vertical",
        status: "ready",
        platforms: { tiktok: true, instagram: true, youtube: true, facebook: true },
      },
      {
        videoId: insertedVideos[2].id,
        channelId: channel.id,
        title: "Why 99% of passive income advice is WRONG",
        description: "🚨 Stop following this bad advice immediately #money #passive #income",
        startTime: 90,
        endTime: 145,
        duration: 55,
        viralScore: 88,
        reason: "Contrarian take that challenges popular beliefs. High share potential.",
        transcript: "Every guru tells you to do the same thing, but the reality is very different...",
        format: "vertical",
        status: "archived",
        platforms: { tiktok: true, instagram: true, youtube: false, facebook: false },
      },
    ];

    for (const c of demoClips) {
      await db.insert(clips).values(c);
    }

    return NextResponse.json({ success: true, channelId: channel.id });
  } catch (err) {
    console.error(err);
    return NextResponse.json({ error: "Seed failed" }, { status: 500 });
  }
}
