"use client";
import { useState } from "react";
import { X, Link2, AlertCircle, CheckCircle2, Loader2 } from "lucide-react";

interface AddChannelModalProps {
  onClose: () => void;
  onSuccess: (channel: Record<string, unknown>) => void;
}

export default function AddChannelModal({ onClose, onSuccess }: AddChannelModalProps) {
  const [url, setUrl] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!url.trim()) return;
    setLoading(true);
    setError("");
    try {
      const res = await fetch("/api/channels", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url: url.trim() }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || "Failed to add channel");
      } else {
        setSuccess(true);
        setTimeout(() => {
          onSuccess(data.channel);
          onClose();
        }, 1200);
      }
    } catch {
      setError("Network error. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const examples = [
    "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
    "https://www.youtube.com/@MrBeast",
    "https://www.youtube.com/channel/UCX6OQ3DkcsbYNE6H8uQQuVA",
    "https://youtu.be/dQw4w9WgXcQ",
  ];

  return (
    <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-gray-900 border border-gray-800 rounded-2xl w-full max-w-lg shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-800">
          <div>
            <h2 className="text-white font-bold text-xl">Connect YouTube Channel</h2>
            <p className="text-gray-400 text-sm mt-1">
              Paste any YouTube URL — video link, channel link, or @handle
            </p>
          </div>
          <button
            onClick={onClose}
            className="text-gray-500 hover:text-gray-300 transition-colors p-1"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-5">
          {/* URL input */}
          <div>
            <label className="text-gray-300 text-sm font-medium mb-2 block">
              YouTube URL
            </label>
            <div className="relative">
              <Link2 className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
              <input
                type="url"
                value={url}
                onChange={(e) => setUrl(e.target.value)}
                placeholder="https://www.youtube.com/watch?v=..."
                className="w-full bg-gray-800 border border-gray-700 rounded-xl pl-10 pr-4 py-3 text-white placeholder-gray-600 focus:outline-none focus:border-violet-500 focus:ring-1 focus:ring-violet-500/30 text-sm"
                disabled={loading || success}
              />
            </div>
          </div>

          {/* Examples */}
          <div>
            <p className="text-gray-500 text-xs mb-2">Supported formats:</p>
            <div className="space-y-1">
              {examples.map((ex) => (
                <button
                  key={ex}
                  type="button"
                  onClick={() => setUrl(ex)}
                  className="block text-xs text-violet-400/70 hover:text-violet-400 truncate w-full text-left transition-colors"
                >
                  {ex}
                </button>
              ))}
            </div>
          </div>

          {/* Error */}
          {error && (
            <div className="flex items-center gap-2 bg-red-950/40 border border-red-800/40 rounded-xl p-3">
              <AlertCircle className="w-4 h-4 text-red-400 flex-shrink-0" />
              <p className="text-red-300 text-sm">{error}</p>
            </div>
          )}

          {/* Success */}
          {success && (
            <div className="flex items-center gap-2 bg-green-950/40 border border-green-800/40 rounded-xl p-3">
              <CheckCircle2 className="w-4 h-4 text-green-400 flex-shrink-0" />
              <p className="text-green-300 text-sm">Channel connected successfully!</p>
            </div>
          )}

          {/* Info box */}
          <div className="bg-blue-950/30 border border-blue-800/30 rounded-xl p-3">
            <p className="text-blue-300 text-xs">
              💡 <strong>Tip:</strong> You can paste a video URL — we&apos;ll automatically find and connect
              the channel. Add your <code className="bg-blue-900/40 px-1 rounded">YOUTUBE_API_KEY</code> in
              Settings to connect real channels.
            </p>
          </div>

          {/* Submit */}
          <button
            type="submit"
            disabled={loading || success || !url.trim()}
            className="w-full bg-violet-600 hover:bg-violet-500 disabled:bg-gray-700 disabled:text-gray-500 text-white font-semibold py-3 rounded-xl transition-colors flex items-center justify-center gap-2"
          >
            {loading ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                Connecting...
              </>
            ) : success ? (
              <>
                <CheckCircle2 className="w-4 h-4" />
                Connected!
              </>
            ) : (
              "Connect Channel"
            )}
          </button>
        </form>
      </div>
    </div>
  );
}
