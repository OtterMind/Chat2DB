import { cn } from "@/lib/utils";
import type { LucideIcon } from "lucide-react";

interface StatCardProps {
  title: string;
  value: string | number;
  subtitle?: string;
  icon: LucideIcon;
  color?: "violet" | "green" | "blue" | "orange" | "red";
  trend?: { value: number; label: string };
}

const colorMap = {
  violet: {
    bg: "bg-violet-500/10 border-violet-700/30",
    icon: "bg-violet-600/20 text-violet-400",
    text: "text-violet-400",
  },
  green: {
    bg: "bg-green-500/10 border-green-700/30",
    icon: "bg-green-600/20 text-green-400",
    text: "text-green-400",
  },
  blue: {
    bg: "bg-blue-500/10 border-blue-700/30",
    icon: "bg-blue-600/20 text-blue-400",
    text: "text-blue-400",
  },
  orange: {
    bg: "bg-orange-500/10 border-orange-700/30",
    icon: "bg-orange-600/20 text-orange-400",
    text: "text-orange-400",
  },
  red: {
    bg: "bg-red-500/10 border-red-700/30",
    icon: "bg-red-600/20 text-red-400",
    text: "text-red-400",
  },
};

export default function StatCard({
  title,
  value,
  subtitle,
  icon: Icon,
  color = "violet",
  trend,
}: StatCardProps) {
  const colors = colorMap[color];
  return (
    <div className={cn("border rounded-2xl p-6 bg-gray-900/60 backdrop-blur", colors.bg)}>
      <div className="flex items-start justify-between">
        <div>
          <p className="text-gray-400 text-sm font-medium mb-1">{title}</p>
          <p className="text-white text-3xl font-bold">{value}</p>
          {subtitle && (
            <p className="text-gray-500 text-xs mt-1">{subtitle}</p>
          )}
          {trend && (
            <div className="flex items-center gap-1 mt-2">
              <span className={cn("text-xs font-medium", trend.value >= 0 ? "text-green-400" : "text-red-400")}>
                {trend.value >= 0 ? "↑" : "↓"} {Math.abs(trend.value)}%
              </span>
              <span className="text-gray-500 text-xs">{trend.label}</span>
            </div>
          )}
        </div>
        <div className={cn("w-11 h-11 rounded-xl flex items-center justify-center flex-shrink-0", colors.icon)}>
          <Icon className="w-5 h-5" />
        </div>
      </div>
    </div>
  );
}
