"use client";
import { useState } from "react";
import { cn, formatDuration, viralScoreColor, viralScoreBg } from "@/lib/utils";
import {
  Clock,
  Zap,
  Play,
  Trash2,
  CheckCircle,
  Share2,
  Archive,
  ChevronDown,
  ChevronUp,
} from "lucide-react";

interface ClipCardProps {
  clip: {
    id: number;
    title: string;
    description: string | null;
    startTime: number;
    endTime: number;
    duration: number;
    viralScore: number | null;
    reason: string | null;
    transcript: string | null;
    status: string | null;
    platforms: Record<string, boolean> | null;
    createdAt: Date | string;
  };
  videoId?: string;
  videoTitle?: string;
  thumbnailUrl?: string;
  onDelete?: (id: number) => void;
  onStatusChange?: (id: number, status: string) => void;
}

const platformIcons: Record<string, string> = {
  tiktok: "🎵",
  instagram: "📸",
  youtube: "▶️",
  facebook: "👍",
};

export default function ClipCard({
  clip,
  videoId,
  thumbnailUrl,
  onDelete,
  onStatusChange,
}: ClipCardProps) {
  const [expanded, setExpanded] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [updating, setUpdating] = useState(false);

  const score = clip.viralScore || 0;
  const ytUrl = videoId
    ? `https://www.youtube.com/watch?v=${videoId}&t=${clip.startTime}s`
    : null;

  const handleDelete = async () => {
    if (!confirm("Delete this clip?")) return;
    setDeleting(true);
    try {
      await fetch(`/api/clips/${clip.id}`, { method: "DELETE" });
      onDelete?.(clip.id);
    } finally {
      setDeleting(false);
    }
  };

  const handleStatus = async (status: string) => {
    setUpdating(true);
    try {
      await fetch(`/api/clips/${clip.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status }),
      });
      onStatusChange?.(clip.id, status);
    } finally {
      setUpdating(false);
    }
  };

  const statusColors: Record<string, string> = {
    ready: "bg-blue-500/20 text-blue-300 border-blue-600/30",
    posted: "bg-green-500/20 text-green-300 border-green-600/30",
    archived: "bg-gray-500/20 text-gray-400 border-gray-600/30",
  };

  return (
    <div className="bg-gray-900 border border-gray-800 rounded-2xl overflow-hidden hover:border-gray-700 transition-colors">
      {/* Thumbnail + header */}
      <div className="relative">
        {thumbnailUrl ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img
            src={thumbnailUrl}
            alt={clip.title}
            className="w-full aspect-video object-cover opacity-70"
          />
        ) : (
          <div className="w-full aspect-video bg-gradient-to-br from-gray-800 to-gray-900 flex items-center justify-center">
            <Play className="w-10 h-10 text-gray-600" />
          </div>
        )}
        {/* Overlay time range */}
        <div className="absolute bottom-2 right-2 bg-black/80 text-white text-xs px-2 py-1 rounded-lg font-mono">
          {formatDuration(clip.startTime)} → {formatDuration(clip.endTime)}
        </div>
        {/* Viral score badge */}
        <div className="absolute top-2 left-2">
          <div className={cn("flex items-center gap-1 px-2 py-1 rounded-lg text-xs font-bold", viralScoreBg(score), "text-white shadow-lg")}>
            <Zap className="w-3 h-3" />
            {score}
          </div>
        </div>
        {/* Status badge */}
        <div className="absolute top-2 right-2">
          <span className={cn("text-[10px] font-semibold px-2 py-1 rounded-lg border uppercase tracking-wide", statusColors[clip.status || "ready"] || statusColors.ready)}>
            {clip.status || "ready"}
          </span>
        </div>
      </div>

      {/* Content */}
      <div className="p-4">
        <h3 className="text-white font-semibold text-sm leading-snug mb-1 line-clamp-2">
          {clip.title}
        </h3>
        <div className="flex items-center gap-3 text-gray-500 text-xs mb-3">
          <span className="flex items-center gap-1">
            <Clock className="w-3 h-3" />
            {formatDuration(clip.duration)}
          </span>
          <span className={cn("font-medium", viralScoreColor(score))}>
            Viral Score: {score}/100
          </span>
        </div>

        {/* Viral score bar */}
        <div className="w-full bg-gray-800 rounded-full h-1 mb-3">
          <div
            className={cn("h-1 rounded-full transition-all", viralScoreBg(score))}
            style={{ width: `${score}%` }}
          />
        </div>

        {/* Platforms */}
        {clip.platforms && (
          <div className="flex items-center gap-2 mb-3">
            <span className="text-gray-500 text-xs">Platforms:</span>
            {Object.entries(clip.platforms)
              .filter(([, v]) => v)
              .map(([k]) => (
                <span key={k} title={k} className="text-base leading-none">
                  {platformIcons[k] || k}
                </span>
              ))}
          </div>
        )}

        {/* Expand reason/transcript */}
        <button
          onClick={() => setExpanded(!expanded)}
          className="flex items-center gap-1 text-gray-500 hover:text-gray-300 text-xs mb-3 transition-colors"
        >
          {expanded ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
          {expanded ? "Hide details" : "Show AI analysis"}
        </button>

        {expanded && (
          <div className="space-y-2 mb-3">
            {clip.reason && (
              <div className="bg-violet-950/40 border border-violet-800/30 rounded-xl p-3">
                <p className="text-violet-300 text-xs font-semibold mb-1">🤖 AI Analysis</p>
                <p className="text-gray-400 text-xs leading-relaxed">{clip.reason}</p>
              </div>
            )}
            {clip.transcript && (
              <div className="bg-gray-800/40 border border-gray-700/30 rounded-xl p-3">
                <p className="text-gray-400 text-xs font-semibold mb-1">📝 Transcript</p>
                <p className="text-gray-500 text-xs leading-relaxed line-clamp-4 italic">
                  &ldquo;{clip.transcript}&rdquo;
                </p>
              </div>
            )}
          </div>
        )}

        {/* Actions */}
        <div className="flex items-center gap-2 flex-wrap">
          {ytUrl && (
            <a
              href={ytUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1.5 bg-gray-800 hover:bg-gray-700 text-gray-300 text-xs px-3 py-1.5 rounded-lg transition-colors"
            >
              <Play className="w-3 h-3" />
              Preview
            </a>
          )}
          {clip.status !== "posted" && (
            <button
              onClick={() => handleStatus("posted")}
              disabled={updating}
              className="flex items-center gap-1.5 bg-green-900/40 hover:bg-green-800/40 text-green-400 text-xs px-3 py-1.5 rounded-lg transition-colors border border-green-700/30 disabled:opacity-50"
            >
              <CheckCircle className="w-3 h-3" />
              Mark Posted
            </button>
          )}
          {clip.status !== "archived" && (
            <button
              onClick={() => handleStatus("archived")}
              disabled={updating}
              className="flex items-center gap-1.5 bg-gray-800 hover:bg-gray-700 text-gray-400 text-xs px-3 py-1.5 rounded-lg transition-colors disabled:opacity-50"
            >
              <Archive className="w-3 h-3" />
            </button>
          )}
          <button
            onClick={() => {
              if (ytUrl) navigator.clipboard.writeText(ytUrl);
            }}
            className="flex items-center gap-1.5 bg-gray-800 hover:bg-gray-700 text-gray-400 text-xs px-3 py-1.5 rounded-lg transition-colors"
          >
            <Share2 className="w-3 h-3" />
          </button>
          <button
            onClick={handleDelete}
            disabled={deleting}
            className="flex items-center gap-1.5 bg-red-900/20 hover:bg-red-900/40 text-red-400 text-xs px-3 py-1.5 rounded-lg transition-colors disabled:opacity-50 ml-auto"
          >
            <Trash2 className="w-3 h-3" />
          </button>
        </div>
      </div>
    </div>
  );
}
