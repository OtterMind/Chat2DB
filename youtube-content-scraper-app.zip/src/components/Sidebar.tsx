"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { cn } from "@/lib/utils";
import {
  LayoutDashboard,
  ListVideo,
  Scissors,
  BarChart3,
  Settings,
  Zap,
} from "lucide-react";

const nav = [
  { href: "/", icon: LayoutDashboard, label: "Dashboard" },
  { href: "/channels", icon: ListVideo, label: "Channels" },
  { href: "/clips", icon: Scissors, label: "Clips" },
  { href: "/analytics", icon: BarChart3, label: "Analytics" },
  { href: "/settings", icon: Settings, label: "Settings" },
];

export default function Sidebar() {
  const path = usePathname();
  return (
    <aside className="fixed left-0 top-0 h-screen w-64 bg-gray-950 border-r border-gray-800 flex flex-col z-40">
      {/* Logo */}
      <div className="px-6 py-5 border-b border-gray-800">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 bg-gradient-to-br from-violet-600 to-indigo-600 rounded-xl flex items-center justify-center shadow-lg shadow-violet-900/50">
            <Scissors className="w-5 h-5 text-white" />
          </div>
          <div>
            <span className="text-white font-bold text-lg leading-none">EasyClip</span>
            <span className="text-violet-400 font-bold text-lg leading-none">.AI</span>
            <p className="text-gray-500 text-[10px] mt-0.5">Video Automation</p>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-4 space-y-1">
        {nav.map(({ href, icon: Icon, label }) => {
          const active = path === href || (href !== "/" && path.startsWith(href));
          return (
            <Link
              key={href}
              href={href}
              className={cn(
                "flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all",
                active
                  ? "bg-violet-600/20 text-violet-300 border border-violet-700/40"
                  : "text-gray-400 hover:bg-gray-800/60 hover:text-gray-200"
              )}
            >
              <Icon className="w-4 h-4 flex-shrink-0" />
              {label}
            </Link>
          );
        })}
      </nav>

      {/* Pro badge */}
      <div className="p-4 border-t border-gray-800">
        <div className="bg-gradient-to-br from-violet-900/50 to-indigo-900/50 border border-violet-700/30 rounded-xl p-4">
          <div className="flex items-center gap-2 mb-2">
            <Zap className="w-4 h-4 text-yellow-400" />
            <span className="text-yellow-400 text-xs font-bold uppercase tracking-wide">Pro Plan</span>
          </div>
          <p className="text-gray-400 text-xs leading-relaxed">
            5 channels • 100 clips/mo • AI B-Roll
          </p>
          <div className="mt-3 w-full bg-gray-700 rounded-full h-1.5">
            <div className="bg-violet-500 h-1.5 rounded-full w-2/5" />
          </div>
          <p className="text-gray-500 text-[10px] mt-1">40 of 100 clips used</p>
        </div>
      </div>
    </aside>
  );
}
