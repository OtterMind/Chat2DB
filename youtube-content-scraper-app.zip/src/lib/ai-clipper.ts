import OpenAI from "openai";
import type { TranscriptSegment } from "./youtube";

let _openai: OpenAI | null = null;
function getOpenAI(): OpenAI {
  if (!_openai) {
    _openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY || "dummy" });
  }
  return _openai;
}

export interface ClipSuggestion {
  title: string;
  description: string;
  startTime: number; // seconds
  endTime: number; // seconds
  duration: number; // seconds
  viralScore: number; // 0-100
  reason: string;
  transcript: string;
  format: "vertical" | "square";
}

// ─── Build full transcript text with timestamps ───────────────────────────────
function buildTranscriptText(segments: TranscriptSegment[]): string {
  return segments
    .map((s) => `[${Math.floor(s.start)}s] ${s.text}`)
    .join("\n");
}

// ─── Find segments within a time range ───────────────────────────────────────
function segmentsInRange(
  segments: TranscriptSegment[],
  start: number,
  end: number
): string {
  return segments
    .filter((s) => s.start >= start - 2 && s.start <= end + 2)
    .map((s) => s.text)
    .join(" ")
    .trim();
}

// ─── Generate viral clip suggestions using AI ─────────────────────────────────
export async function generateClipSuggestions(
  videoTitle: string,
  segments: TranscriptSegment[],
  videoDuration: number,
  maxClips = 5
): Promise<ClipSuggestion[]> {
  const transcriptText = buildTranscriptText(segments);
  const maxChars = 12000;
  const truncated =
    transcriptText.length > maxChars
      ? transcriptText.slice(0, maxChars) + "\n...[truncated]"
      : transcriptText;

  const prompt = `You are an expert viral short-form content creator. Analyze this YouTube video transcript and identify the TOP ${maxClips} most viral moments suitable for TikTok, Instagram Reels, and YouTube Shorts (60 seconds max each, ideally 30-60s).

VIDEO TITLE: ${videoTitle}
VIDEO DURATION: ${videoDuration} seconds

TRANSCRIPT (with timestamps in seconds):
${truncated}

Identify viral moments based on:
- Hook potential (first 3 seconds must grab attention)
- Emotional resonance (funny, inspiring, shocking, educational)
- Quotable/shareable quotes
- Story arcs with clear beginning/middle/end
- High-energy or emotionally charged moments
- "Aha!" moments or surprising revelations

Return ONLY valid JSON array with this exact structure:
[
  {
    "title": "Catchy clip title (max 60 chars)",
    "description": "TikTok/Reels caption with hashtags",
    "startTime": 45,
    "endTime": 105,
    "viralScore": 87,
    "reason": "Why this moment will go viral (2-3 sentences)",
    "format": "vertical"
  }
]

Rules:
- startTime and endTime must be valid numbers within the video duration (0 to ${videoDuration})
- Each clip must be 15-60 seconds long
- viralScore must be 0-100 (be realistic, most clips are 40-75)
- format is always "vertical" for mobile platforms
- Vary the clips across different moments in the video
- NO markdown, NO explanation, ONLY the JSON array`;

  const response = await getOpenAI().chat.completions.create({
    model: "gpt-4o-mini",
    messages: [{ role: "user", content: prompt }],
    temperature: 0.7,
    max_tokens: 2000,
    response_format: { type: "json_object" },
  });

  const content = response.choices[0].message.content || "{}";
  
  let parsed: { clips?: ClipSuggestion[] } | ClipSuggestion[] = [];
  try {
    parsed = JSON.parse(content);
  } catch {
    return [];
  }

  // Handle both {clips: [...]} and [...] formats
  const rawClips: ClipSuggestion[] = Array.isArray(parsed)
    ? parsed
    : (parsed as { clips?: ClipSuggestion[] }).clips || [];

  // Validate and enrich clips
  return rawClips
    .filter((c) => {
      const start = Number(c.startTime);
      const end = Number(c.endTime);
      return (
        !isNaN(start) &&
        !isNaN(end) &&
        start >= 0 &&
        end <= videoDuration + 10 &&
        end - start >= 10 &&
        end - start <= 120
      );
    })
    .slice(0, maxClips)
    .map((c) => ({
      title: c.title || "Clip",
      description: c.description || "",
      startTime: Math.floor(Number(c.startTime)),
      endTime: Math.floor(Number(c.endTime)),
      duration: Math.floor(Number(c.endTime) - Number(c.startTime)),
      viralScore: Math.min(100, Math.max(0, Number(c.viralScore) || 50)),
      reason: c.reason || "",
      transcript: segmentsInRange(
        segments,
        Number(c.startTime),
        Number(c.endTime)
      ),
      format: "vertical" as const,
    }));
}

// ─── Generate mock clips when no API key ──────────────────────────────────────
export function generateMockClips(
  videoTitle: string,
  segments: TranscriptSegment[],
  videoDuration: number,
  count = 5
): ClipSuggestion[] {
  const clipDuration = 45;
  const clips: ClipSuggestion[] = [];
  const step = Math.max(30, Math.floor((videoDuration - clipDuration) / count));

  const hooks = [
    "You won't believe this...",
    "The secret they don't tell you",
    "This changed everything",
    "Nobody talks about this",
    "The truth about",
  ];
  const reasons = [
    "Strong hook with emotional storytelling that resonates with audiences",
    "Educational moment with surprising revelation that drives shares",
    "High-energy segment with quotable insight perfect for Shorts",
    "Relatable moment that sparks comments and engagement",
    "Controversial take that generates discussion and replays",
  ];

  for (let i = 0; i < count && i * step + clipDuration <= videoDuration; i++) {
    const start = Math.floor(i * step + 10);
    const end = Math.min(start + clipDuration, videoDuration - 5);
    const transcript = segmentsInRange(segments, start, end);
    clips.push({
      title: `${hooks[i % hooks.length]} ${videoTitle.slice(0, 30)}`,
      description: `🔥 ${videoTitle} #shorts #viral #trending #fyp`,
      startTime: start,
      endTime: end,
      duration: end - start,
      viralScore: 55 + Math.floor(Math.random() * 35),
      reason: reasons[i % reasons.length],
      transcript: transcript || `[Clip from ${start}s to ${end}s]`,
      format: "vertical",
    });
  }
  return clips;
}

// ─── Summarize video with AI ──────────────────────────────────────────────────
export async function summarizeVideo(
  title: string,
  segments: TranscriptSegment[]
): Promise<string> {
  const text = segments.map((s) => s.text).join(" ").slice(0, 8000);
  
  const response = await getOpenAI().chat.completions.create({
    model: "gpt-4o-mini",
    messages: [
      {
        role: "user",
        content: `Summarize this YouTube video in 2-3 sentences for a content creator dashboard:\n\nTitle: ${title}\n\nTranscript: ${text}`,
      },
    ],
    max_tokens: 200,
  });
  return response.choices[0].message.content || "";
}
