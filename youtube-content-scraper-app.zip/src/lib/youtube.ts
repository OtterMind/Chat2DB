const YT_API_KEY = process.env.YOUTUBE_API_KEY;
const BASE = "https://www.googleapis.com/youtube/v3";

export interface YTChannelInfo {
  channelId: string;
  channelName: string;
  channelUrl: string;
  thumbnailUrl: string;
  description: string;
  subscriberCount: number;
  videoCount: number;
}

export interface YTVideoInfo {
  videoId: string;
  title: string;
  description: string;
  thumbnailUrl: string;
  duration: number; // seconds
  viewCount: number;
  likeCount: number;
  commentCount: number;
  publishedAt: Date;
}

function parseDuration(iso: string): number {
  const match = iso.match(/PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?/);
  if (!match) return 0;
  return (
    (parseInt(match[1] || "0") * 3600) +
    (parseInt(match[2] || "0") * 60) +
    parseInt(match[3] || "0")
  );
}

// ─── Resolve channel from URL or video URL ────────────────────────────────────
export async function resolveChannelFromVideoUrl(
  videoUrl: string
): Promise<{ videoId: string; channelId: string; channelHandle?: string } | null> {
  const patterns = [
    /(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/shorts\/)([a-zA-Z0-9_-]{11})/,
  ];
  let videoId: string | null = null;
  for (const p of patterns) {
    const m = videoUrl.match(p);
    if (m) { videoId = m[1]; break; }
  }
  if (!videoId) return null;

  const url = `${BASE}/videos?part=snippet&id=${videoId}&key=${YT_API_KEY}`;
  const res = await fetch(url);
  const data = await res.json();
  if (!data.items?.length) return null;
  const snippet = data.items[0].snippet;
  return { videoId, channelId: snippet.channelId };
}

// ─── Fetch channel info by channelId ─────────────────────────────────────────
export async function fetchChannelInfo(channelId: string): Promise<YTChannelInfo | null> {
  const url = `${BASE}/channels?part=snippet,statistics&id=${channelId}&key=${YT_API_KEY}`;
  const res = await fetch(url);
  const data = await res.json();
  if (!data.items?.length) return null;
  const item = data.items[0];
  return {
    channelId: item.id,
    channelName: item.snippet.title,
    channelUrl: `https://www.youtube.com/channel/${item.id}`,
    thumbnailUrl: item.snippet.thumbnails?.high?.url || item.snippet.thumbnails?.default?.url || "",
    description: item.snippet.description || "",
    subscriberCount: parseInt(item.statistics.subscriberCount || "0"),
    videoCount: parseInt(item.statistics.videoCount || "0"),
  };
}

// ─── Fetch channel info by handle (@username) ─────────────────────────────────
export async function fetchChannelByHandle(handle: string): Promise<YTChannelInfo | null> {
  // Try forHandle (works for @handles)
  const cleanHandle = handle.startsWith("@") ? handle : `@${handle}`;
  const url = `${BASE}/channels?part=snippet,statistics&forHandle=${encodeURIComponent(cleanHandle)}&key=${YT_API_KEY}`;
  const res = await fetch(url);
  const data = await res.json();
  if (data.items?.length) {
    const item = data.items[0];
    return {
      channelId: item.id,
      channelName: item.snippet.title,
      channelUrl: `https://www.youtube.com/channel/${item.id}`,
      thumbnailUrl: item.snippet.thumbnails?.high?.url || "",
      description: item.snippet.description || "",
      subscriberCount: parseInt(item.statistics.subscriberCount || "0"),
      videoCount: parseInt(item.statistics.videoCount || "0"),
    };
  }
  // Fallback: search by username
  const searchUrl = `${BASE}/search?part=snippet&type=channel&q=${encodeURIComponent(handle)}&maxResults=1&key=${YT_API_KEY}`;
  const searchRes = await fetch(searchUrl);
  const searchData = await searchRes.json();
  if (searchData.items?.length) {
    return fetchChannelInfo(searchData.items[0].snippet.channelId);
  }
  return null;
}

// ─── Fetch videos from channel ────────────────────────────────────────────────
export async function fetchChannelVideos(
  channelId: string,
  maxResults = 20
): Promise<YTVideoInfo[]> {
  // First get the upload playlist
  const chanRes = await fetch(
    `${BASE}/channels?part=contentDetails&id=${channelId}&key=${YT_API_KEY}`
  );
  const chanData = await chanRes.json();
  if (!chanData.items?.length) return [];
  const uploadsPlaylist =
    chanData.items[0].contentDetails.relatedPlaylists.uploads;

  // Get playlist items
  const playRes = await fetch(
    `${BASE}/playlistItems?part=snippet&playlistId=${uploadsPlaylist}&maxResults=${maxResults}&key=${YT_API_KEY}`
  );
  const playData = await playRes.json();
  if (!playData.items?.length) return [];

  const videoIds = playData.items
    .map((i: { snippet: { resourceId: { videoId: string } } }) => i.snippet.resourceId.videoId)
    .join(",");

  // Get video details
  const vidRes = await fetch(
    `${BASE}/videos?part=snippet,contentDetails,statistics&id=${videoIds}&key=${YT_API_KEY}`
  );
  const vidData = await vidRes.json();
  if (!vidData.items?.length) return [];

  return vidData.items.map((item: {
    id: string;
    snippet: {
      title: string;
      description: string;
      thumbnails: { maxres?: { url: string }; high?: { url: string }; default?: { url: string } };
      publishedAt: string;
    };
    contentDetails: { duration: string };
    statistics: {
      viewCount?: string;
      likeCount?: string;
      commentCount?: string;
    };
  }) => ({
    videoId: item.id,
    title: item.snippet.title,
    description: item.snippet.description || "",
    thumbnailUrl:
      item.snippet.thumbnails?.maxres?.url ||
      item.snippet.thumbnails?.high?.url ||
      item.snippet.thumbnails?.default?.url ||
      "",
    duration: parseDuration(item.contentDetails.duration),
    viewCount: parseInt(item.statistics.viewCount || "0"),
    likeCount: parseInt(item.statistics.likeCount || "0"),
    commentCount: parseInt(item.statistics.commentCount || "0"),
    publishedAt: new Date(item.snippet.publishedAt),
  }));
}

// ─── Fetch transcript via YouTube's timedtext endpoint ────────────────────────
export interface TranscriptSegment {
  text: string;
  start: number;
  duration: number;
}

export async function fetchTranscript(
  videoId: string
): Promise<TranscriptSegment[] | null> {
  try {
    const { YoutubeTranscript } = await import("youtube-transcript");
    const raw = await YoutubeTranscript.fetchTranscript(videoId, { lang: "en" });
    return raw.map((s) => ({
      text: s.text,
      start: s.offset / 1000,
      duration: s.duration / 1000,
    }));
  } catch {
    // Try without language
    try {
      const { YoutubeTranscript } = await import("youtube-transcript");
      const raw = await YoutubeTranscript.fetchTranscript(videoId);
      return raw.map((s) => ({
        text: s.text,
        start: s.offset / 1000,
        duration: s.duration / 1000,
      }));
    } catch {
      return null;
    }
  }
}
